<?php
session_start();
$_SESSION['landingViewed'] = TRUE;
if (isset($clickData))
 $link = "api .php?" . http_build_query($_GET) . (empty($_GET) ? ("clickid=") : ("&clickid=")) . $clickData['clickid'];
else 
 $link = "api.php?" .http_build_query($_GET);
?>
<!DOCTYPE html>
<html>

<head>
    <!-- 438 - 1868 [o48;l6] botas-scnd -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BOTAŞ</title>
    <meta name="description" content="Boru Hatları İle Petrol Taşıma Anonim Şirketi">
    <link rel="shortcut icon" href="favicon.ico">
    <link href="assets/landing/css/landing.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/style.css">
<!--[HEADER]--></head>

<body>
    <header class="header">
        <div class="header__top">
            <ul class="header__list header__list--top">
                <li class="header__item header__item--top">
                    <a data-scroll="scrollto" class="header__link">Müşteri</a>
                </li>
                <li class="header__item header__item--top">
                    <a data-scroll="scrollto" class="header__link">Bilgi Merkezi</a>
                </li>
                <li class="header__item header__item--top">
                    <a data-scroll="scrollto" class="header__link">Tarifeler</a>
                </li>
                <li class="header__item header__item--top">
                    <a data-scroll="scrollto" class="header__link">Personel</a>
                </li>
            </ul>
            <ul class="header__list header__list--social">
                <li class="header__item header__item--social">
                    <a data-scroll="scrollto" class="header__link header__link--social"><img src="img/twitter-dark.svg"
                            width="20" height="20" alt="twitter"></a>
                </li>
                <li class="header__item header__item--social">
                    <a data-scroll="scrollto" class="header__link header__link--social"><img
                            src="img/instagram-dark.svg" width="20" height="20" alt="instagram"></a>
                </li>
                <li class="header__item header__item--social">
                    <a data-scroll="scrollto" class="header__link header__link--social"><img src="img/linkedin-dark.svg"
                            width="20" height="20" alt="linkedin"></a>
                </li>
                <li class="header__item header__item--social">
                    <a data-scroll="scrollto" class="header__link header__link--social"><img src="img/youtube-dark.svg"
                            width="20" height="20" alt="youtube"></a>
                </li>
                <li class="header__item header__item--social">
                    <a data-scroll="scrollto" class="header__link header__link--social"><img src="img/spotify-dark.svg"
                            width="20" height="20" alt="spotify"></a>
                </li>
            </ul>
            <img class="header__banner" src="img/img_1.webp" width="200" height="40" alt="banner">
        </div>
        <div class="header__bottom">
            <img src="img/logo.svg" width="50" height="60" alt="BOTAS logo" class="header__logo">
            <ul class="header__list">
                <li class="header__item">
                    <a data-scroll="scrollto" class="header__link">HAKKIMIZDA <img src="img/arrow-down.svg" width="8"
                            height="4" alt="see more"></a>
                </li>
                <li class="header__item">
                    <a data-scroll="scrollto" class="header__link">FAALİYETLERİMİZ <img src="img/arrow-down.svg"
                            width="8" height="4" alt="see more"></a>
                </li>
                <li class="header__item">
                    <a data-scroll="scrollto" class="header__link">SÜRDÜRÜLEBİLİRLİK <img src="img/arrow-down.svg"
                            width="8" height="4" alt="see more"></a>
                </li>
                <li class="header__item">
                    <a data-scroll="scrollto" class="header__link">MEDYA <img src="img/arrow-down.svg" width="8"
                            height="4" alt="see more"></a>
                </li>
                <li class="header__item">
                    <a data-scroll="scrollto" class="header__link">İLETİŞİM <img src="img/arrow-down.svg" width="8"
                            height="4" alt="see more"></a>
                </li>
            </ul>
            <img class="header__icon" src="img/search.svg" width="20" height="20" alt="search">
        </div>
    </header>
    <main>
        <section class="promo">
            <div class="promo__body">
                <div class="promo__side">
                    <form class="form form--column" action="<?=$link;?>" method="post">
<?php require 'assets/php/landing_form.php'; ?>
                        <p class="form__title">ISTIKRARLI&nbsp;BIR GELECEK <br> I&Ccedil;IN BIZE KATILIN</p>
                        <input class="form__input form__input--column" name="forename" placeholder="Adınız" type="text"
                            required=">
                        <input class="form__input form__input--column" name="surname" placeholder="Soy adınız"
                            type="text" required=">
                        <input class="form__input form__input--column" name="email" placeholder="E-posta adresiniz"
                            type="email" required=">
                        <input class="form__input form__input--column phone phone-tr" placeholder="501 234-56-78"
                            type="tel" name="phone" required=">
                        <button class="form__btn form__btn--column" type="submit" name="submit">Kazanmaya
                            başlamak</button>
                        <label class="form__check" for="check">
                            <input type="checkbox" name="check" id="check" checked>
                            Kullanım Koşullarımız ve <a class="form__link" id="policy1">Gizlilik Politikamızda</a>
                            detayları
                            verilen şirketler ve sektörler adına ilginizi çekeceğini düşündüğümüz ticari teklifler almak
                            amacıyla e-posta adresimin alınmasına izin veriyorum.
                        </label>
                        
                        
                        
                    
<input type="hidden" name="phonecc" value="90" class="phonecc" />
<input type="hidden" name ="country" value="tr" />
<input type="hidden" name="comment" value="" />
</form>
                </div>
                <div class="promo__side">
                    <h1 class="promo__title">Botaş hisselerini <span>5.000 TL'den</span> başlayan miktarla satın alarak
                        her ay <span>70.000</span>
                        kazanabilirsiniz</h1>
                </div>
            </div>
            <ul class="promo__list">
                <li class="promo__item promo__item--light">
                    <a data-scroll="scrollto" class="promo__link">
                        <img src="img/icon_13.svg" width="40" height="40" alt>
                        <p class="promo__desc">
                            <span class="promo__desc--light">Duyurular</span>
                            <span class="promo__desc--middle">BOTAŞ Saros FSRU Terminali Taslak Kullanım Usul ve
                                Esasları Hakkında</span>
                        </p>
                    </a>
                </li>
                <li class="promo__item promo__item--dark">
                    <a data-scroll="scrollto" class="promo__link">
                        <img src="img/icon_14.svg" width="40" height="40" alt>
                        <p class="promo__desc">
                            <span class="promo__desc--light">İhale İlanları</span>
                            <span class="promo__desc--middle">BOTAŞ EGE İŞLETME MÜDÜRLÜĞÜ REHABİLTASYON İHALESİ</span>
                        </p>
                    </a>
                </li>
            </ul>
        </section>
        <section class="section video">
            <h2 class="video__title">BOTAŞ, gaz ticaretine izin verdi</h2>
            <p class="video__desc">Artık milli kaynaklar sizin elinizde!</p>
            <div class="video-wrapper embed-responsive embed-container">
                <div class="poster_block">
                    <img class="poster" src="img/poster.webp" alt="poster video">
                    <img class="play-btn" src="img/play.webp" alt="play btn">
                </div>
            </div>
        </section>
        <section class="section section--news news">
            <div class="news__top">
                <h2 class="news__title">Haberler</h2>
                <a data-scroll="scrollto" class="news__desc news__desc--hide">TÜMÜNÜ GÖSTER <img src="img/arrow.svg"
                        width="20" height="5" alt="see more"></a>
            </div>
            <div class="news__body">
                <div class="news__side">
                    <div class="news__card">
                        <img src="img/img_2.webp" width="590" height="332"
                            alt="Yeşil Dünya Ödülleri'ne 2023'te de BOTAŞ İmzası">
                        <div class="news__about">
                            <a data-scroll="scrollto" class="news__date">2 Mayıs 2023 <img src="img/arrow.svg"
                                    width="20" height="5" alt="see more"></a>
                            <h3 class="news__subtitle news__subtitle--dark">Yeşil Dünya Ödülleri'ne 2023'te de BOTAŞ
                                İmzası</h3>
                        </div>
                    </div>
                </div>
                <div class="news__side">
                    <div class="slider" id="slider">
                        <img class="card--prev" src="img/prev.svg" width="20" height="20" alt="prev">
                        <div class="slider__wrap">
                            <ul class="slider__content">
                                <li class="card">
                                    <img src="img/img_3.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">12 Nisan 2023 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Türkiye'den Bulgaristan'a Doğal Gaz Akışı Başladı
                                        </h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_4.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">31 Mart 2023 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Türkiye'nin İlk Çift Yakıtlı Römorkörü BOTAŞ İçin
                                            İnşa Ediliyor</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_5.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">20 Şubat 2023 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Büyük BOTAŞ Ailesi Büyük Türkiye ile Tek Bilek Tek
                                            Yürek</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_6.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">17 Şubat 2023 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Ertuğrul Gazi FSRU Gemisi Depremde Gaz Sistemine Can
                                            Oldu</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_7.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">30 Ocak 2023 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Türkiye ile Umman Arasında Tarihi Anlaşma</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_8.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">19 Ocak 2023 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Enerjiye Yön Verenler BOTAŞ 5.Sürdürülebilir Enerji
                                            Zirvesi'nde Buluştu</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_9.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">3 Ocak 2023 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Türkiye İle Bulgaristan, Doğal Gaz Alanında İş
                                            Birliği Anlaşması İmzaladı</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_10.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">21 Aralık 2022 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Enerji Merkezi Olma Yolunda BOTAŞ'tan Dev Adım</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_11.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">30 Kasım 2022 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Yeşil Elma Ödülleri'ne 2022'de de BOTAŞ Damgası</h3>
                                    </div>
                                </li>
                                <li class="card">
                                    <img src="img/img_12.webp" width="253" height="300" alt>
                                    <div class="card__about">
                                        <a data-scroll="scrollto" class="card__date">28 Ekim 2022 <img
                                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                                        <h3 class="card__subtitle">Yerli Yazılım KOVAN İçin İmzalar Atıldı</h3>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <img class="card--next" src="img/next.svg" width="20" height="20" alt="next">
                    </div>
                </div>
            </div>
            <h2 class="news__title">Faaliyet Alanlarımız</h2>
            <ul class="news__list">
                <li class="news__item">
                    <div class="news__link">
                        <div class="news__header">
                            <img src="img/icon_9.webp" width="45" height="45" alt>
                            <h3 class="news__subtitle">İletim (Taşıma)</h3>
                        </div>
                        <div class="news__footer">
                            <a data-scroll="scrollto" class="news__desc news__desc--light">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
                <li class="news__item">
                    <div class="news__link">
                        <div class="news__header">
                            <img src="img/icon_10.webp" width="45" height="45" alt>
                            <h3 class="news__subtitle">Ticaret</h3>
                        </div>
                        <div class="news__footer">
                            <a data-scroll="scrollto" class="news__desc news__desc--light">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
                <li class="news__item">
                    <div class="news__link">
                        <div class="news__header">
                            <img src="img/icon_11.webp" width="45" height="45" alt>
                            <h3 class="news__subtitle">Depolama</h3>
                        </div>
                        <div class="news__footer">
                            <a data-scroll="scrollto" class="news__desc news__desc--light">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
                <li class="news__item">
                    <div class="news__link">
                        <div class="news__header">
                            <img src="img/icon_12.webp" width="45" height="45" alt>
                            <h3 class="news__subtitle">Liman Hizmetleri</h3>
                        </div>
                        <div class="news__footer">
                            <a data-scroll="scrollto" class="news__desc news__desc--light">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
            </ul>
        </section>
        <section class="section section--sustainability sustainability">
            <h2 class="sustainability__title">Sürdürülebilirlik</h2>
            <ul class="sustainability__list">
                <li class="sustainability__item">
                    <div class="sustainability__link">
                        <div class="sustainability__header">
                            <img src="img/icon_5.webp" width="45" height="45" alt>
                            <h3 class="sustainability__subtitle">Sosyal Faaliyetler</h3>
                        </div>
                        <div class="sustainability__footer">
                            <a data-scroll="scrollto" class="sustainability__desc">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
                <li class="sustainability__item">
                    <div class="sustainability__link">
                        <div class="sustainability__header">
                            <img src="img/icon_6.webp" width="45" height="45" alt>
                            <h3 class="sustainability__subtitle">Çevre</h3>
                        </div>
                        <div class="sustainability__footer">
                            <a data-scroll="scrollto" class="sustainability__desc">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
                <li class="sustainability__item">
                    <div class="sustainability__link">
                        <div class="sustainability__header">
                            <img src="img/icon_7.webp" width="45" height="45" alt>
                            <h3 class="sustainability__subtitle">İSG</h3>
                        </div>
                        <div class="sustainability__footer">
                            <a data-scroll="scrollto" class="sustainability__desc">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
                <li class="sustainability__item">
                    <div class="sustainability__link">
                        <div class="sustainability__header">
                            <img src="img/icon_8.webp" width="45" height="45" alt>
                            <h3 class="sustainability__subtitle">Enerji Verimliliği</h3>
                        </div>
                        <div class="sustainability__footer">
                            <a data-scroll="scrollto" class="sustainability__desc">DAHA FAZLASI <img
                                    src="img/arrow-white.svg" width="30" height="5" alt="see more"></a>
                        </div>
                    </div>
                </li>
            </ul>
        </section>
        <section class="section section--info info">
            <div class="info__top">
                <ul class="info__list--title">
                    <li class="info__item--title active" id="infoFrst">
                        <h2 class="info__title info__title--right">Ulusal Projelerimiz</h2>
                    </li>
                    <li class="info__item--title" id="infoScnd">
                        <h2 class="info__title">Uluslararası Projelerimiz</h2>
                    </li>
                </ul>
                <div class="info__wrap" id="wrapFrst">
                    <ul class="info__list--filter">
                        <li class="info__item--filter active" id="filterFrst">
                            Boru Hattı
                        </li>
                        <li class="info__item--filter" id="filterScnd">
                            Depolama
                        </li>
                        <li class="info__item--filter" id="filterThrd">
                            FSRU
                        </li>
                        <li class="info__item--filter" id="filterFrth">
                            Kompresör İstasyonu
                        </li>
                    </ul>
                    <ul class="info__filter">
                        <li class="info__filter-item" id="subfilterFrst">
                            <ul class="info__subfilter">
                                <li class="info__subfilter-item">
                                    <a data-scroll="scrollto" class="filtercard filtercard--column">
                                        <img src="img/img_15.webp" width="200" height="215" alt>
                                        <p class="filtercard__about">
                                            Büyük BOTAŞ Ailesi Büyük Türkiye ile Tek Bilek Tek Yürek
                                        </p>
                                    </a>
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                            </ul>
                        </li>
                        <li class="info__filter-item hide" id="subfilterScnd">
                            <ul class="info__subfilter">
                                <li class="info__subfilter-item">
                                    <a data-scroll="scrollto" class="filtercard filtercard--column">
                                        <img src="img/img_16.webp" width="200" height="215" alt>
                                        <p class="filtercard__about">
                                            Tuz Gölü Doğal Gaz Depolama
                                        </p>
                                    </a>
                                </li>
                                <li class="info__subfilter-item">
                                    <a data-scroll="scrollto" class="filtercard filtercard--column">
                                        <img src="img/img_17.webp" width="200" height="215" alt>
                                        <p class="filtercard__about">
                                            Kuzey Marmara Doğal Gaz Depolama Tevsi Projesi
                                        </p>
                                    </a>
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                            </ul>
                        </li>
                        <li class="info__filter-item hide" id="subfilterThrd">
                            <ul class="info__subfilter">
                                <li class="info__subfilter-item">
                                    <a data-scroll="scrollto" class="filtercard filtercard--column">
                                        <img src="img/img_18.webp" width="200" height="215" alt>
                                        <p class="filtercard__about">
                                            Saros FSRU
                                        </p>
                                    </a>
                                </li>
                                <li class="info__subfilter-item">
                                    <a data-scroll="scrollto" class="filtercard filtercard--column">
                                        <img src="img/img_19.webp" width="200" height="215" alt>
                                        <p class="filtercard__about">
                                            Dörtyol FSRU
                                        </p>
                                    </a>
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                            </ul>
                        </li>
                        <li class="info__filter-item hide" id="subfilterFrth">
                            <ul class="info__subfilter">
                                <li class="info__subfilter-item">
                                    <a data-scroll="scrollto" class="filtercard filtercard--column">
                                        <img src="img/img_20.webp" width="200" height="215" alt>
                                        <p class="filtercard__about">
                                            Sivas Kompresör İstasyonu Yedek Ünite Kurulumu
                                        </p>
                                    </a>
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                                <li class="info__subfilter-item">
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="info__wrap hide" id="wrapScnd">
                    <ul class="info__list--filter">
                        <li class="info__item--filter active" id="filterFrst">
                            TANAP
                        </li>
                        <li class="info__item--filter" id="filterScnd">
                            TürkAkım Projesi
                        </li>
                    </ul>
                    <ul class="info__filter">
                        <li class="info__filter-item" id="subfilterFrst">
                            <a data-scroll="scrollto" class="filtercard filtercard--row">
                                <img src="img/img_13.webp" width="200" height="215" alt>
                                <p class="filtercard__desc">
                                    <span>Trans Anadolu Doğal Gaz Boru Hattı (TANAP) Azerbaycan doğal gazını Posof’ta SCP (South Caucasus Pipeline) Hattı’ndan devralarak, Yunanistan’ın İpsala sınırında TAP’a (Trans-Adriatic Pipeline) bağlanmakta ve Güney Gaz Koridorunun temelini oluşturmaktadır.</span>
                                    <span>TANAP’ın BOTAŞ iletim sistemine bağlantısı amacıyla yürütülen TANAP-Eskişehir Doğal Gaz Bağlantı Hattı Projesi inşaat çalışmaları tamamlanarak 12 Haziran 2018’de açılmıştır. 30 Haziran 2018 tarihinde Türkiye’ye Eskişehir’den doğal gaz sağlayacak olan Faz-0 bölümü tamamlanarak doğal gazın ülkemize teslimatına başlamıştır.</span>
                                    <span>Projenin Eskişehir Edirne/İpsala arasındaki Faz-1 bölümünde de inşaat çalışmaları tamamlanmış ve Avrupa Bağlantısı Açılış Töreni 30 Kasım 2019 tarihinde yapılmış olup Avrupa‘ya doğal gaz temini 2020 yılında başlamıştır.</span>
                                </p>
                            </a>
                        </li>
                        <li class="info__filter-item hide" id="subfilterScnd">
                            <a data-scroll="scrollto" class="filtercard filtercard--row">
                                <img src="img/img_14.webp" width="200" height="215" alt>
                                <p class="filtercard__desc">
                                    <span>Karadeniz tabanına inşa edilen TürkAkım Doğal Gaz Boru Hattı (TürkAkım), Rusya ve Türkiye’nin doğal gaz iletim şebekelerini birbirine bağlamaktadır. Toplam kapasitesi 31,5 milyar m<sup>3</sup> olan iki hattan oluşan boru hattının, birinci bölümü Türkiye’ye doğal gaz tedarik ederken, ikinci bölümü ise Türkiye toprakları üzerinden Güney ve Güneydoğu Avrupa ülkelerine doğal gaz taşıyacaktır.</span>
                                    <span>Rusya'nın Anapa şehrinden başlayan ve Kırklareli ili Kıyıköy beldesinde sona eren yaklaşık 930 km uzunluğundaki Karadeniz geçişli deniz kısmında yer alan her iki hattın inşası 19 Kasım 2018 itibarıyla tamamlanmıştır.</span>
                                </p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <ul class="info__list">
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M10 2.5C5.85938 2.5 2.5 5.85938 2.5 10C2.5 14.1406 5.85938 17.5 10 17.5C10.6914 17.5 11.25 18.0586 11.25 18.75C11.25 19.4414 10.6914 20 10 20C4.47656 20 0 15.5234 0 10C0 4.47656 4.47656 0 10 0C15.5234 0 20 4.47656 20 10V11.25C20 13.3203 18.3203 15 16.25 15C15.1055 15 14.0781 14.4844 13.3906 13.6758C12.5 14.4961 11.3086 15 10 15C7.23828 15 5 12.7617 5 10C5 7.23828 7.23828 5 10 5C11.0898 5 12.0977 5.34766 12.918 5.94141C13.1406 5.74609 13.4297 5.625 13.75 5.625C14.4414 5.625 15 6.18359 15 6.875V10V11.25C15 11.9414 15.5586 12.5 16.25 12.5C16.9414 12.5 17.5 11.9414 17.5 11.25V10C17.5 5.85938 14.1406 2.5 10 2.5ZM12.5 10C12.5 9.33696 12.2366 8.70107 11.7678 8.23223C11.2989 7.76339 10.663 7.5 10 7.5C9.33696 7.5 8.70107 7.76339 8.23223 8.23223C7.76339 8.70107 7.5 9.33696 7.5 10C7.5 10.663 7.76339 11.2989 8.23223 11.7678C8.70107 12.2366 9.33696 12.5 10 12.5C10.663 12.5 11.2989 12.2366 11.7678 11.7678C12.2366 11.2989 12.5 10.663 12.5 10Z"
                                fill="#CF0A11" />
                        </svg>
                        ÖNERI
                    </a>
                </li>
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M6.82422 1.76172C7.50781 0.664062 8.71094 0 10 0C11.2891 0 12.4922 0.664062 13.1758 1.76172L14.6836 4.17188L15.7383 3.5625C16.0664 3.37109 16.4766 3.39844 16.7773 3.62891C17.0781 3.85938 17.2109 4.25 17.1133 4.61719L16.1992 8.03125C16.0664 8.53125 15.5508 8.82813 15.0508 8.69531L11.6367 7.78125C11.2695 7.68359 11 7.375 10.9492 7C10.8984 6.625 11.082 6.25391 11.4102 6.06641L12.5195 5.42578L11.0547 3.08594C10.8281 2.72266 10.4297 2.5 10 2.5C9.57031 2.5 9.17188 2.72266 8.94531 3.08594L8.26172 4.17969C7.90234 4.75781 7.14453 4.94141 6.55859 4.58984C5.96094 4.23047 5.76953 3.44922 6.14062 2.85547L6.82422 1.76172ZM16.7773 9.83984C17.3633 9.48828 18.1211 9.67188 18.4805 10.25L19.4336 11.7773C19.8008 12.3672 19.9961 13.043 20.0039 13.7383C20.0156 15.8125 18.3359 17.5039 16.2617 17.5039L12.5 17.5V18.75C12.5 19.1289 12.2734 19.4727 11.9219 19.6172C11.5703 19.7617 11.168 19.6836 10.8984 19.4141L8.39844 16.9141C8.03125 16.5469 8.03125 15.9531 8.39844 15.5898L10.8984 13.0898C11.168 12.8203 11.5703 12.7422 11.9219 12.8867C12.2734 13.0313 12.5 13.375 12.5 13.7539V15.0039H16.2578C16.9453 15.0039 17.5039 14.4414 17.5 13.7539C17.5 13.5234 17.4336 13.2969 17.3125 13.1016L16.3594 11.5742C15.9883 10.9805 16.1758 10.1992 16.7773 9.83984ZM2.53516 8.62891L1.40625 7.97656C1.07812 7.78516 0.894531 7.41797 0.945312 7.04297C0.996094 6.66797 1.26562 6.35938 1.63281 6.26172L5.04687 5.34766C5.54687 5.21484 6.0625 5.51172 6.19531 6.01172L7.10938 9.42188C7.20703 9.78906 7.07422 10.1758 6.77344 10.4102C6.47266 10.6445 6.0625 10.668 5.73438 10.4766L4.69922 9.87891L2.6875 13.0977C2.56641 13.293 2.5 13.5195 2.5 13.75C2.49609 14.4375 3.05469 15 3.74219 15H5C5.69141 15 6.25 15.5586 6.25 16.25C6.25 16.9414 5.69141 17.5 5 17.5H3.74219C1.66797 17.5 -0.0117188 15.8125 -8.69368e-08 13.7344C0.00390616 13.0391 0.199219 12.3633 0.570312 11.7734L2.53516 8.62891Z"
                                fill="#CF0A11" />
                        </svg>
                        SIFIR ATIK
                    </a>
                </li>
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M8.125 1.875C8.125 1.37772 8.32254 0.900806 8.67417 0.549175C9.02581 0.197544 9.50272 0 10 0C10.4973 0 10.9742 0.197544 11.3258 0.549175C11.6775 0.900806 11.875 1.37772 11.875 1.875C11.875 2.37228 11.6775 2.84919 11.3258 3.20083C10.9742 3.55246 10.4973 3.75 10 3.75C9.50272 3.75 9.02581 3.55246 8.67417 3.20083C8.32254 2.84919 8.125 2.37228 8.125 1.875ZM6.25 7.5C6.25 6.80859 6.80859 6.25 7.5 6.25H10C10.6914 6.25 11.25 6.80859 11.25 7.5V16.25H12.5C13.1914 16.25 13.75 16.8086 13.75 17.5C13.75 18.1914 13.1914 18.75 12.5 18.75H7.5C6.80859 18.75 6.25 18.1914 6.25 17.5C6.25 16.8086 6.80859 16.25 7.5 16.25H8.75V8.75H7.5C6.80859 8.75 6.25 8.19141 6.25 7.5Z"
                                fill="#CF0A11" />
                        </svg>
                        BİLGİ EDİNME
                    </a>
                </li>
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M2.50004 2.5C2.50004 1.83696 2.76344 1.20107 3.23228 0.732233C3.70112 0.263392 4.337 0 5.00004 0C5.66309 0 6.29897 0.263392 6.76781 0.732233C7.23665 1.20107 7.50004 1.83696 7.50004 2.5C7.50004 3.16304 7.23665 3.79893 6.76781 4.26777C6.29897 4.73661 5.66309 5 5.00004 5C4.337 5 3.70112 4.73661 3.23228 4.26777C2.76344 3.79893 2.50004 3.16304 2.50004 2.5ZM1.01176 9.11719C1.14458 7.49609 2.50004 6.25 4.12504 6.25H5.87504C6.92973 6.25 7.86723 6.77344 8.43364 7.58203C8.32817 7.65625 8.23051 7.73828 8.14067 7.82812L5.64067 10.3281C4.7852 11.1836 4.7852 12.5664 5.64067 13.4219L7.50004 15.2812V18.125C7.50004 19.1602 6.6602 20 5.62504 20H4.37504C3.33989 20 2.50004 19.1602 2.50004 18.125V13.6055C1.46489 13.2344 0.75395 12.207 0.851607 11.043L1.01176 9.11719ZM17.5 2.5C17.5 1.83696 17.7634 1.20107 18.2323 0.732233C18.7011 0.263392 19.337 0 20 0C20.6631 0 21.299 0.263392 21.7678 0.732233C22.2367 1.20107 22.5 1.83696 22.5 2.5C22.5 3.16304 22.2367 3.79893 21.7678 4.26777C21.299 4.73661 20.6631 5 20 5C19.337 5 18.7011 4.73661 18.2323 4.26777C17.7634 3.79893 17.5 3.16304 17.5 2.5ZM16.8594 7.82812C16.7696 7.73828 16.668 7.65625 16.5665 7.58203C17.1329 6.77344 18.0743 6.25 19.125 6.25H20.875C22.5 6.25 23.8555 7.49609 23.9883 9.11719L24.1485 11.043C24.2461 12.207 23.5352 13.2344 22.5 13.6055V18.125C22.5 19.1602 21.6602 20 20.625 20H19.375C18.3399 20 17.5 19.1602 17.5 18.125V15.2812L19.3594 13.4219C20.2149 12.5664 20.2149 11.1836 19.3594 10.3281L16.8594 7.82812ZM10.625 9.375V10.625H14.375V9.375C14.375 8.99609 14.6016 8.65234 14.9532 8.50781C15.3047 8.36328 15.7071 8.44141 15.9766 8.71094L18.4766 11.2109C18.8438 11.5781 18.8438 12.1719 18.4766 12.5352L15.9766 15.0352C15.7071 15.3047 15.3047 15.3828 14.9532 15.2383C14.6016 15.0938 14.375 14.75 14.375 14.3711V13.125H10.625V14.375C10.625 14.7539 10.3985 15.0977 10.0469 15.2422C9.69536 15.3867 9.29301 15.3086 9.02348 15.0391L6.52348 12.5391C6.15629 12.1719 6.15629 11.5781 6.52348 11.2148L9.02348 8.71484C9.29301 8.44531 9.69536 8.36719 10.0469 8.51172C10.3985 8.65625 10.625 9 10.625 9.37891V9.375Z"
                                fill="#CF0A11" />
                        </svg>
                        YÖNETİM SİSTEMLERİMİZ
                    </a>
                </li>
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="27" height="20" viewBox="0 0 27 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M21.1138 0C23.5553 0.137549 25.5154 0.859684 26.0312 2.92292C26.3407 4.09209 25.9968 5.29565 25.5842 6.15533C25.1371 7.08379 24.6557 7.80593 24.0368 8.52806C22.8332 9.93794 21.4233 11.0727 19.8071 12.1043C18.2253 13.136 16.5059 14.03 14.649 14.7522C13.7549 15.096 12.7577 15.4399 11.6573 15.6806C10.6257 15.9213 9.31897 16.0933 8.18419 15.8182C7.11818 15.5775 6.29288 15.0273 6.12095 13.9613C5.94901 12.7921 6.5336 11.8292 7.04941 11.0727C8.11541 9.52529 9.59407 8.39051 11.279 7.49644C12.964 6.56798 14.8897 5.81146 17.4688 5.91462C15.3711 6.15533 13.9613 6.77431 12.5514 7.66838C11.3478 8.45929 9.90355 9.62846 9.45652 11.2447C9.14703 12.3451 9.66284 13.1016 10.4194 13.4455C11.1759 13.7893 12.3794 13.8237 13.3423 13.7206C15.3368 13.5486 16.9873 12.8265 18.3628 12.07C20.4605 10.9008 22.3174 9.35336 23.5897 7.25573C24.0024 6.56798 24.3806 5.77707 24.587 4.91739C25.0684 2.57905 23.9336 1.30672 22.2486 0.790909C20.5636 0.275099 18.0877 0.550198 16.3684 0.997233C12.8953 1.92569 10.1099 3.61067 7.63399 5.60514C6.43043 6.56798 5.33004 7.70276 4.29842 8.94071C3.30118 10.1787 2.40711 11.5541 1.82253 13.1016C1.54743 13.9613 1.30672 14.9241 1.44427 15.9557C1.78814 18.7067 4.67668 19.532 7.94348 19.3601C12.07 19.1194 15.1992 17.7095 18.0534 16.1277C15.4743 17.7095 12.3451 19.2225 8.7 19.7727C4.6079 20.4605 0.275099 19.7039 0 15.887V15.1992C0.275099 12.6202 1.51304 10.7289 2.75099 9.14703C4.09209 7.42767 5.57075 6.08656 7.25573 4.84862C8.90632 3.57628 10.7976 2.51028 12.8609 1.65059C14.9241 0.790909 17.2968 0.137549 19.979 0H21.1138ZM22.1798 4.77984C21.9735 5.26126 21.664 5.77707 21.4233 6.29288C22.0767 6.36166 22.7988 6.36166 23.4866 6.43043C22.6613 6.73992 21.8016 7.01502 20.9419 7.29012C20.6668 7.84031 20.3573 8.39051 20.0822 8.94071C19.8071 8.59684 19.6008 8.18419 19.3257 7.84031L16.8498 8.66561C17.5375 8.18419 18.2253 7.66838 18.913 7.18695C18.7067 6.84308 18.466 6.49921 18.2597 6.15533C18.7411 6.18972 19.2225 6.22411 19.7039 6.22411C19.8759 6.22411 20.0478 6.29288 20.1854 6.2585C20.3229 6.22411 20.5636 6.01778 20.7012 5.91462C21.1826 5.53636 21.6984 5.12371 22.1798 4.77984Z"
                                fill="#CF0A11" />
                        </svg>
                        E-DEVLET HİZMETLERİ
                    </a>
                </li>
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="17" height="20" viewBox="0 0 17 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path class="no-fill"
                                d="M1.30618 1.4355L1.30417 1.43608C1.02957 1.51597 0.829726 1.57686 0.679799 1.63352C0.528462 1.69071 0.44889 1.73619 0.402439 1.77611C0.330869 1.83762 0.300806 1.91011 0.269606 2.2533L0.269614 2.2533L0.269419 2.25527C0.18394 3.11956 0.38503 4.82229 0.755849 6.69878C1.12479 8.56576 1.65371 10.5656 2.20414 12.0105L2.20437 12.0111L2.76775 13.5013L3.75191 13.6222L3.75192 13.6221L3.75537 13.6226C4.46114 13.7193 6.49163 13.7695 8.51906 13.7695C9.52831 13.7695 10.5299 13.7571 11.3552 13.7323C12.1872 13.7074 12.8233 13.6702 13.1127 13.6235L13.1127 13.6235L13.1157 13.623L13.9078 13.5051L14.4711 12.0695C14.4712 12.0693 14.4713 12.069 14.4714 12.0688C15.0389 10.591 15.52 8.37012 15.8613 6.4081C16.2033 4.4425 16.3987 2.77446 16.4044 2.40587C16.4075 2.20416 16.408 2.07394 16.3927 1.9737C16.3791 1.88428 16.3557 1.83917 16.3206 1.80211C16.2783 1.7574 16.1991 1.70376 16.0344 1.63787C15.8712 1.57257 15.6471 1.50395 15.334 1.41703C14.0847 1.07023 11.7319 0.525875 10.8113 0.388774C9.48856 0.191766 7.80019 0.215654 6.30555 0.389821C4.81282 0.563766 2.48813 1.0809 1.30618 1.4355Z"
                                stroke="#CF0A11" stroke-width="0.5" />
                            <path
                                d="M1.71017 18.5329C1.82931 18.5329 1.9339 18.51 2.02394 18.4643C2.11537 18.4186 2.18672 18.3528 2.23797 18.2669C2.28923 18.181 2.31486 18.0778 2.31486 17.9573C2.31486 17.8367 2.28715 17.7363 2.23174 17.656C2.17771 17.5756 2.10498 17.5153 2.01355 17.4752C1.92212 17.435 1.82099 17.4149 1.71017 17.4149H1.1221C1.08332 17.4149 1.05699 17.4225 1.04314 17.4378C1.03067 17.4516 1.02444 17.4793 1.02444 17.5209V18.4435C1.02444 18.4795 1.03067 18.5038 1.04314 18.5162C1.05699 18.5273 1.08262 18.5329 1.12003 18.5329H1.71017ZM1.13249 17.0866H1.65614C1.75589 17.0866 1.84801 17.0693 1.93251 17.0346C2.0184 16.9986 2.08767 16.9432 2.14031 16.8684C2.19295 16.7922 2.21927 16.6939 2.21927 16.5733C2.21927 16.4528 2.19364 16.3558 2.14239 16.2824C2.09113 16.209 2.02325 16.1557 1.93875 16.1224C1.85424 16.0892 1.76004 16.0725 1.65614 16.0725H1.10756C1.0757 16.0725 1.05353 16.0788 1.04106 16.0912C1.02998 16.1023 1.02444 16.1245 1.02444 16.1577V16.991C1.02444 17.0353 1.03137 17.0624 1.04522 17.072C1.05907 17.0817 1.08816 17.0866 1.13249 17.0866ZM1.7642 18.8612H0.0872748C0.0512566 18.8612 0.0277063 18.8556 0.0166238 18.8446C0.00554125 18.8335 0 18.8099 0 18.7739V18.6014C0 18.571 0.00554125 18.5523 0.0166238 18.5453C0.0277063 18.537 0.0471007 18.5329 0.0748069 18.5329H0.367801C0.402434 18.5329 0.425984 18.528 0.438452 18.5183C0.45092 18.5072 0.457154 18.4844 0.457154 18.4497V16.1598C0.457154 16.1224 0.45092 16.0989 0.438452 16.0892C0.427369 16.0781 0.403126 16.0725 0.365723 16.0725H0.0851968C0.0491786 16.0725 0.0256283 16.0684 0.0145458 16.0601C0.00484858 16.0518 0 16.0296 0 15.9936V15.8232C0 15.7913 0.00484858 15.7705 0.0145458 15.7608C0.0256283 15.7498 0.046408 15.7442 0.0768849 15.7442H1.66861C1.91104 15.7442 2.11745 15.7726 2.28785 15.8294C2.45824 15.8848 2.58707 15.9714 2.67435 16.0892C2.76301 16.2069 2.80734 16.3579 2.80734 16.5422C2.80734 16.7195 2.76509 16.8629 2.68058 16.9723C2.59608 17.0804 2.4714 17.1579 2.30655 17.205C2.2733 17.2147 2.25737 17.2265 2.25875 17.2404C2.26014 17.2542 2.27607 17.2653 2.30655 17.2736C2.5088 17.3221 2.66534 17.4045 2.77617 17.5209C2.88838 17.6373 2.94448 17.7931 2.94448 17.9884C2.94448 18.2004 2.89946 18.3701 2.80942 18.4975C2.72076 18.625 2.58846 18.7178 2.41252 18.776C2.23659 18.8328 2.02048 18.8612 1.7642 18.8612Z"
                                fill="#CF0A11" />
                            <path
                                d="M3.46323 17.3027C3.46323 17.0755 3.49925 16.8643 3.57128 16.6689C3.64332 16.4736 3.74653 16.3025 3.8809 16.1557C4.01666 16.0088 4.18152 15.8945 4.37546 15.8128C4.57079 15.7311 4.79036 15.6902 5.03418 15.6902C5.27799 15.6902 5.49687 15.7311 5.69081 15.8128C5.88476 15.8945 6.04961 16.0088 6.18537 16.1557C6.32113 16.3025 6.42503 16.4736 6.49707 16.6689C6.5691 16.8643 6.60512 17.0755 6.60512 17.3027C6.60512 17.5299 6.56703 17.7412 6.49083 17.9365C6.41603 18.1318 6.30866 18.3029 6.16875 18.4497C6.03022 18.5966 5.86467 18.7109 5.67211 18.7926C5.48094 18.8743 5.26829 18.9152 5.03418 18.9152C4.79036 18.9152 4.57079 18.8743 4.37546 18.7926C4.18152 18.7109 4.01666 18.5966 3.8809 18.4497C3.74653 18.3029 3.64332 18.1318 3.57128 17.9365C3.49925 17.7412 3.46323 17.5299 3.46323 17.3027ZM4.12195 17.3027C4.12195 17.4856 4.13926 17.656 4.1739 17.8139C4.20853 17.9718 4.26186 18.1103 4.3339 18.2295C4.40732 18.3486 4.50152 18.4414 4.6165 18.5079C4.73287 18.5744 4.87209 18.6077 5.03418 18.6077C5.20596 18.6077 5.35003 18.5744 5.46639 18.5079C5.58415 18.4414 5.67835 18.3486 5.749 18.2295C5.81965 18.1103 5.87021 17.9718 5.90069 17.8139C5.93117 17.656 5.9464 17.4856 5.9464 17.3027C5.9464 17.1185 5.92909 16.9481 5.89446 16.7915C5.85982 16.6336 5.8058 16.4951 5.73237 16.3759C5.66034 16.2568 5.56614 16.164 5.44977 16.0975C5.33479 16.031 5.19626 15.9977 5.03418 15.9977C4.87209 15.9977 4.73287 16.031 4.6165 16.0975C4.50152 16.164 4.40732 16.2568 4.3339 16.3759C4.26186 16.4951 4.20853 16.6336 4.1739 16.7915C4.13926 16.9481 4.12195 17.1185 4.12195 17.3027Z"
                                fill="#CF0A11" />
                            <path
                                d="M7.80625 18.7697V18.616C7.80625 18.58 7.81249 18.5571 7.82495 18.5474C7.83881 18.5377 7.86236 18.5329 7.89561 18.5329H8.21561C8.26687 18.5329 8.29943 18.5259 8.31328 18.5121C8.32713 18.4982 8.33406 18.465 8.33406 18.4123V16.1411C8.33406 16.1051 8.32852 16.0815 8.31743 16.0705C8.30635 16.058 8.28349 16.0518 8.24886 16.0518H8.09717C7.92955 16.0518 7.79863 16.0739 7.70443 16.1183C7.61162 16.1612 7.54581 16.236 7.50703 16.3427C7.46824 16.448 7.44676 16.5948 7.44261 16.7832C7.44122 16.8206 7.43499 16.8462 7.42391 16.8601C7.41282 16.8726 7.3865 16.8788 7.34494 16.8788H7.22858C7.19256 16.8788 7.1697 16.8705 7.16001 16.8539C7.15169 16.8372 7.14754 16.8123 7.14754 16.7791V15.8564C7.14754 15.8093 7.15169 15.7789 7.16001 15.765C7.1697 15.7512 7.19741 15.7442 7.24312 15.7442H9.97773C10.0165 15.7442 10.0401 15.7505 10.0484 15.7629C10.0581 15.7754 10.0629 15.8017 10.0629 15.8419V16.7978C10.0629 16.8352 10.0567 16.858 10.0442 16.8663C10.0331 16.8746 10.0082 16.8788 9.96942 16.8788H9.86137C9.81842 16.8788 9.7921 16.8712 9.7824 16.8559C9.77409 16.8407 9.76924 16.8144 9.76786 16.777C9.7637 16.59 9.74154 16.4438 9.70136 16.3385C9.66257 16.2332 9.59608 16.1591 9.50188 16.1162C9.40906 16.0732 9.27884 16.0518 9.11122 16.0518H8.95537C8.92212 16.0518 8.90065 16.058 8.89095 16.0705C8.88126 16.0815 8.87641 16.1051 8.87641 16.1411V18.3999C8.87641 18.4567 8.88264 18.4934 8.89511 18.51C8.90758 18.5252 8.94152 18.5329 8.99693 18.5329H9.30863C9.35157 18.5329 9.37789 18.5398 9.38759 18.5536C9.39867 18.5675 9.40421 18.5959 9.40421 18.6388V18.7656C9.40421 18.8099 9.39452 18.8369 9.37512 18.8466C9.35573 18.8563 9.32594 18.8612 9.28577 18.8612H7.906C7.86444 18.8612 7.83742 18.8563 7.82495 18.8466C7.81249 18.8369 7.80625 18.8113 7.80625 18.7697Z"
                                fill="#CF0A11" />
                            <path
                                d="M11.7328 16.3905L11.2341 17.5624C11.223 17.5888 11.2189 17.6089 11.2217 17.6227C11.2258 17.6366 11.2494 17.6435 11.2923 17.6435H12.1609C12.2191 17.6435 12.2489 17.6359 12.2503 17.6206C12.253 17.6054 12.2475 17.5784 12.2336 17.5396L11.8076 16.3967C11.791 16.3524 11.7779 16.3316 11.7682 16.3344C11.7599 16.3371 11.7481 16.3558 11.7328 16.3905ZM10.0289 18.7656V18.6014C10.0289 18.5765 10.0338 18.5592 10.0434 18.5495C10.0531 18.5384 10.0712 18.5329 10.0975 18.5329H10.3842C10.4258 18.5329 10.4521 18.5259 10.4632 18.5121C10.4743 18.4982 10.4861 18.4781 10.4985 18.4518L11.6767 15.7172C11.6837 15.7006 11.6906 15.6909 11.6975 15.6881C11.7058 15.684 11.7224 15.6819 11.7474 15.6819H12.0508C12.0757 15.6819 12.093 15.6847 12.1027 15.6902C12.1124 15.6957 12.1214 15.7075 12.1297 15.7255L13.2061 18.431C13.22 18.4657 13.2311 18.4913 13.2394 18.5079C13.2491 18.5245 13.2788 18.5329 13.3287 18.5329H13.6404C13.6709 18.5329 13.691 18.537 13.7007 18.5453C13.7104 18.5523 13.7152 18.571 13.7152 18.6014V18.7822C13.7152 18.8169 13.7111 18.839 13.7028 18.8487C13.6958 18.857 13.675 18.8612 13.6404 18.8612H12.2253C12.1948 18.8612 12.1734 18.857 12.1609 18.8487C12.1498 18.839 12.1443 18.8175 12.1443 18.7843V18.6056C12.1443 18.5737 12.1498 18.5536 12.1609 18.5453C12.172 18.537 12.1928 18.5329 12.2232 18.5329H12.5162C12.5578 18.5329 12.5793 18.5259 12.5807 18.5121C12.5834 18.4968 12.58 18.4761 12.5703 18.4497L12.4248 18.0591C12.4096 18.0175 12.3964 17.9905 12.3853 17.978C12.3742 17.9656 12.3396 17.9593 12.2814 17.9593H11.1739C11.1295 17.9593 11.0991 17.9642 11.0824 17.9739C11.0658 17.9822 11.0513 18.0016 11.0388 18.0321L10.8684 18.4373C10.8546 18.4705 10.8504 18.4948 10.8559 18.51C10.8615 18.5252 10.8857 18.5329 10.9287 18.5329H11.2133C11.2397 18.5329 11.257 18.5377 11.2653 18.5474C11.275 18.5557 11.2798 18.5737 11.2798 18.6014V18.7926C11.2798 18.8259 11.2757 18.8459 11.2674 18.8529C11.2604 18.8584 11.2404 18.8612 11.2071 18.8612H10.1432C10.0989 18.8612 10.0684 18.857 10.0518 18.8487C10.0365 18.839 10.0289 18.8113 10.0289 18.7656Z"
                                fill="#CF0A11" />
                            <path
                                d="M15.0294 19.9396V19.8545C15.0294 19.8309 15.035 19.8157 15.046 19.8087C15.0571 19.8032 15.073 19.7997 15.0938 19.7983C15.1783 19.7914 15.2566 19.7748 15.3286 19.7485C15.4007 19.7222 15.4367 19.6778 15.4367 19.6155C15.4367 19.5642 15.4166 19.5247 15.3764 19.497C15.3376 19.4693 15.2871 19.4492 15.2247 19.4368C15.1638 19.4257 15.1021 19.4174 15.0398 19.4118C14.9996 19.4077 14.9768 19.4008 14.9712 19.3911C14.9657 19.3828 14.9698 19.3696 14.9837 19.3516L15.3037 18.9131C15.3106 18.9034 15.3162 18.8972 15.3203 18.8944C15.3259 18.893 15.3369 18.8923 15.3536 18.8923H15.4886C15.5205 18.8923 15.5357 18.8951 15.5344 18.9007C15.5344 18.9076 15.5288 18.9187 15.5177 18.9339L15.3577 19.1542C15.3397 19.1777 15.3321 19.1923 15.3349 19.1978C15.339 19.2034 15.3598 19.2075 15.3972 19.2103C15.5163 19.22 15.6119 19.2518 15.684 19.3059C15.7574 19.3599 15.7941 19.4451 15.7941 19.5615C15.7941 19.6487 15.7726 19.7201 15.7297 19.7755C15.6867 19.8323 15.6299 19.8766 15.5593 19.9085C15.4886 19.9403 15.4118 19.9625 15.3286 19.975C15.2455 19.9888 15.1631 19.9971 15.0814 19.9999C15.0467 20.0013 15.0294 19.9812 15.0294 19.9396ZM16.1619 16.7042C16.1467 16.5602 16.1009 16.4362 16.0248 16.3323C15.9486 16.2284 15.8523 16.1487 15.7359 16.0933C15.6196 16.0365 15.4935 16.0081 15.3577 16.0081C15.1472 16.0081 14.9955 16.0497 14.9027 16.1328C14.8098 16.2145 14.7634 16.3164 14.7634 16.4383C14.7634 16.5477 14.796 16.635 14.8611 16.7001C14.9276 16.7652 15.0149 16.8185 15.1229 16.8601C15.2324 16.9003 15.3515 16.937 15.4803 16.9702C15.6105 17.0035 15.7408 17.0416 15.871 17.0845C16.0012 17.1275 16.1203 17.1843 16.2284 17.2549C16.3378 17.3242 16.4251 17.4156 16.4902 17.5292C16.5567 17.6428 16.59 17.7876 16.59 17.9635C16.59 18.1782 16.5422 18.3576 16.4466 18.5017C16.351 18.6444 16.2145 18.7517 16.0372 18.8238C15.8613 18.8944 15.6528 18.9298 15.4118 18.9298C15.2455 18.9298 15.0959 18.9034 14.9629 18.8508C14.8313 18.7968 14.7198 18.7296 14.6284 18.6492C14.5937 18.6174 14.5695 18.6049 14.5556 18.6118C14.5432 18.6188 14.5265 18.6451 14.5058 18.6908L14.4476 18.8238C14.4365 18.8501 14.424 18.866 14.4102 18.8716C14.3977 18.8785 14.3714 18.882 14.3312 18.882H14.2086C14.174 18.882 14.1504 18.8771 14.138 18.8674C14.1255 18.8591 14.1193 18.8383 14.1193 18.8051V17.8264C14.1193 17.7917 14.1248 17.7709 14.1359 17.764C14.147 17.7557 14.1691 17.7515 14.2024 17.7515H14.3541C14.3873 17.7515 14.4067 17.7578 14.4123 17.7702C14.4192 17.7813 14.424 17.8021 14.4268 17.8326C14.4406 17.96 14.485 18.084 14.5598 18.2045C14.636 18.3251 14.7392 18.4241 14.8694 18.5017C14.9996 18.5793 15.1541 18.6181 15.3328 18.6181C15.5004 18.6181 15.6369 18.5924 15.7422 18.5412C15.8474 18.4899 15.9243 18.4241 15.9728 18.3438C16.0227 18.2634 16.0476 18.1796 16.0476 18.0923C16.0476 17.9718 16.0144 17.8755 15.9479 17.8035C15.8828 17.7315 15.7962 17.674 15.6881 17.631C15.5801 17.5867 15.4609 17.5486 15.3307 17.5167C15.2019 17.4835 15.0724 17.4475 14.9421 17.4087C14.8119 17.3685 14.6928 17.3166 14.5847 17.2528C14.4767 17.1891 14.3894 17.1046 14.3229 16.9993C14.2578 16.8926 14.2252 16.7555 14.2252 16.5879C14.2252 16.4327 14.2536 16.299 14.3104 16.1868C14.3672 16.0746 14.4441 15.9825 14.5411 15.9105C14.6394 15.837 14.751 15.783 14.8756 15.7484C15.0003 15.7137 15.1305 15.6964 15.2663 15.6964C15.4062 15.6964 15.5357 15.7179 15.6549 15.7608C15.774 15.8038 15.8765 15.8613 15.9624 15.9333C15.9915 15.9569 16.0151 15.9693 16.0331 15.9707C16.0511 15.9707 16.0698 15.9499 16.0892 15.9084L16.1494 15.7775C16.1577 15.765 16.1647 15.7567 16.1702 15.7525C16.1758 15.747 16.1896 15.7442 16.2118 15.7442H16.4009C16.43 15.7442 16.4487 15.7491 16.457 15.7588C16.4667 15.7685 16.4715 15.7892 16.4715 15.8211V16.7271C16.4715 16.7604 16.466 16.7811 16.4549 16.7894C16.4438 16.7964 16.421 16.7998 16.3863 16.7998H16.2554C16.2083 16.7998 16.182 16.7943 16.1764 16.7832C16.1723 16.7707 16.1674 16.7444 16.1619 16.7042Z"
                                fill="#CF0A11" />
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M6.95927 2.61739C6.97917 2.49801 7.15824 2.15976 7.397 1.86131C7.61587 1.58276 7.91432 1.34399 8.0337 1.34399C8.19288 1.34399 8.17298 1.42358 8.0138 1.58276C7.67556 1.921 7.71535 2.19956 8.09339 2.06028C8.33215 1.98069 8.39184 2.02049 8.29236 2.23935C8.13319 2.65718 8.33215 2.61739 8.73009 2.15976C8.92906 1.9409 9.2872 1.70214 9.56576 1.64245L10.0632 1.48327L9.66524 1.9409C9.32699 2.33884 9.3071 2.39853 9.62545 2.27914C10.0234 2.13987 10.0831 2.33884 9.72493 2.69698C9.38668 3.03522 9.78462 2.97553 10.2422 2.63729C10.6999 2.29904 11.4759 2.23935 11.6549 2.5378C11.7146 2.63729 11.6151 2.73677 11.4361 2.73677C11.1575 2.73677 11.1376 2.79646 11.3167 2.97553C11.4957 3.1546 11.456 3.25409 11.1973 3.45306C10.9187 3.67192 10.9784 3.69182 11.6549 3.61223C12.212 3.53264 12.5702 3.59233 12.8487 3.8112L12.8487 3.8112L12.8487 3.81121C13.0292 3.96317 13.1235 4.04259 13.11 4.07111C13.0953 4.10235 12.9513 4.07256 12.6498 4.01017C12.1125 3.91068 12.0927 3.93058 12.411 4.18924C12.7294 4.46779 12.7294 4.48769 12.3115 4.62697L11.8539 4.74635L12.3712 4.90552C13.1273 5.14429 13.7441 5.50243 13.7441 5.72129C13.7441 5.82078 13.5849 5.84067 13.4058 5.78098C13.1671 5.6815 13.1074 5.74119 13.2069 5.97995C13.2865 6.21871 13.2467 6.2784 12.988 6.19882C12.7294 6.11923 12.7492 6.17892 13.0676 6.45748C13.4854 6.79572 13.9431 7.5319 13.9431 7.83036C13.9431 7.90994 13.7441 7.81046 13.5053 7.59159C13.1074 7.23345 13.0875 7.23345 13.2069 7.5717C13.3263 7.87015 13.2666 7.90994 12.8885 7.79056L12.4508 7.67118L12.9084 8.14871C13.1472 8.42726 13.3462 8.88489 13.3462 9.22313L13.3263 9.80014L13.0477 9.30272C12.8089 8.88489 12.7691 8.86499 12.7492 9.18334C12.7492 9.48179 12.6896 9.50169 12.4707 9.32262C12.2319 9.12365 12.212 9.20324 12.2916 9.85983C12.3513 10.2976 12.2916 10.8149 12.1722 11.0138C11.9932 11.3521 11.9733 11.3521 11.9534 10.8945C11.9335 10.4368 11.9136 10.4169 11.6748 10.7552C11.3963 11.1133 11.3963 11.1133 11.2968 10.7552C11.2371 10.5164 11.1973 10.5562 11.1774 10.9144C11.1774 11.2128 10.9784 11.6505 10.7397 11.9092L10.3417 12.3867L10.481 11.8893C10.6004 11.4516 10.5805 11.4317 10.282 11.6704C10.0035 11.9092 9.96369 11.8893 9.96369 11.571C9.9438 11.3123 9.84431 11.4118 9.60555 11.8694C9.42648 12.2474 9.04844 12.6255 8.78978 12.725C8.31226 12.8841 8.31226 12.8841 8.63061 12.526C9.06834 12.0485 9.06834 11.8694 8.63061 12.0286C8.41174 12.1082 8.35205 12.0883 8.45153 11.9291C8.6704 11.571 8.39184 11.6505 7.83473 12.0883C7.55618 12.3071 7.13834 12.4862 6.91948 12.4862C6.52154 12.4862 6.50165 12.4862 6.89958 12.1878C7.08985 12.0398 7.17903 11.9704 7.16714 11.9349C7.15665 11.9036 7.06746 11.8986 6.89958 11.8893C6.60113 11.8893 6.58123 11.8296 6.7802 11.5909C6.93938 11.4118 6.95927 11.2924 6.82 11.2924C6.70061 11.2924 6.54144 11.372 6.48175 11.4914C6.32258 11.75 4.98949 11.75 4.98949 11.4914C4.98949 11.372 5.14866 11.2924 5.34763 11.2924C5.62619 11.2924 5.64608 11.2526 5.38743 11.0934C5.12877 10.9343 5.12877 10.8746 5.36753 10.7154C5.5665 10.596 5.40732 10.5363 4.89 10.5363C4.45227 10.5363 4.01454 10.397 3.81558 10.1981C3.51712 9.87973 3.53702 9.85983 3.99465 9.99911C4.43238 10.1384 4.45227 10.1185 4.21351 9.82004C3.97475 9.54148 3.99465 9.50169 4.313 9.48179C4.59155 9.48179 4.51197 9.4022 4.09413 9.20324C3.75589 9.06396 3.31816 8.74561 3.09929 8.50685L2.70135 8.04922L3.13908 8.1885C3.49723 8.30788 3.57681 8.26809 3.47733 8.02932C3.37785 7.79056 3.43754 7.73087 3.6763 7.83036C3.87527 7.90994 3.73599 7.69108 3.39774 7.35283C2.78094 6.71613 2.50239 5.82078 3.09929 6.3182C3.33805 6.51717 3.39774 6.51717 3.39774 6.3182C3.39774 6.17892 3.53702 6.11923 3.6962 6.19882C3.97475 6.2983 3.97475 6.2784 3.6962 5.88047C3.53702 5.62181 3.39774 5.16418 3.41764 4.82594V4.22903L3.63651 4.72645C3.81558 5.14429 3.87527 5.16418 3.93496 4.86573C4.01454 4.60707 4.09413 4.56728 4.2732 4.70656C4.47217 4.88563 4.51197 4.72645 4.43238 3.95048C4.39258 3.35357 4.43238 2.93574 4.57166 2.85615C4.71093 2.75667 4.79052 2.89595 4.79052 3.1745C4.80048 3.39354 4.80545 3.50298 4.83536 3.51028C4.86522 3.51757 4.91994 3.42306 5.02928 3.23419L5.02928 3.23419C5.14063 3.04187 5.19533 2.94739 5.24316 2.95075C5.28934 2.95399 5.32912 3.04847 5.40732 3.23419C5.5466 3.57244 5.5665 3.55254 5.5665 3.11481C5.58639 2.81636 5.76546 2.37863 6.00423 2.11997L6.40216 1.64245L6.28278 2.08018C6.20319 2.35873 6.24299 2.5378 6.36237 2.5378C6.48175 2.5378 6.58123 2.41842 6.60113 2.27914C6.60113 2.15976 6.68072 2.21945 6.7802 2.43832C6.87969 2.65718 6.95927 2.73677 6.95927 2.61739ZM8.62357 6.3311C9.03917 6.22721 9.9327 6.5389 10.1821 6.9545C10.1821 6.5389 10.3552 5.00114 10.4937 4.37775L11.0132 4.27385C10.8054 4.16995 10.3483 3.98293 10.1821 4.06605C10.0554 4.1294 9.45792 5.04977 8.9969 5.75999L8.99689 5.76L8.99686 5.76006C8.85299 5.98168 8.72242 6.18284 8.62357 6.3311ZM6.64951 9.86373L6.64951 4.461H7.4807V7.65942C7.73523 7.237 8.19836 6.95448 8.72748 6.95448C9.53082 6.95448 10.1821 7.60572 10.1821 8.40906C10.1821 9.21241 9.53082 9.86364 8.72748 9.86364C8.19836 9.86364 7.73523 9.58112 7.4807 9.15871V9.86373H6.64951ZM9.55868 8.40904C9.55868 8.86809 9.18654 9.24023 8.72749 9.24023C8.26844 9.24023 7.8963 8.86809 7.8963 8.40904C7.8963 7.94999 8.26844 7.57785 8.72749 7.57785C9.18654 7.57785 9.55868 7.94999 9.55868 8.40904Z"
                                fill="#CF0A11" />
                        </svg>
                        BASINDA BOTAŞ
                    </a>
                </li>
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="15" height="20" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M6 1.16797L6.625 0.335938C6.78125 0.125 7.03125 0 7.29297 0C7.75 0 8.125 0.375 8.125 0.832031V1.69922C8.125 2.21094 8.33594 2.70312 8.70703 3.05469L12.0156 6.21094C13.9219 8.03125 15 10.5547 15 13.1914C15 16.9531 11.9531 20 8.19141 20H7.5C3.35938 20 0 16.6406 0 12.5V12.3516C0 10.4453 0.757813 8.61719 2.10547 7.26953L2.24219 7.13281C2.40625 6.96875 2.63281 6.875 2.86719 6.875C3.35547 6.875 3.75 7.26953 3.75 7.75781V11.25C3.75 12.6289 4.87109 13.75 6.25 13.75C7.62891 13.75 8.75 12.6289 8.75 11.25V11.0977C8.75 10.3945 8.46875 9.71875 7.97266 9.22266L6.46484 7.71484C5.52734 6.77734 5 5.5 5 4.17188C5 3.08984 5.35156 2.03125 6 1.16797Z"
                                fill="#CF0A11" />
                        </svg>
                        KURUMSAL KİMLİK
                    </a>
                </li>
                <li class="info__item">
                    <a data-scroll="scrollto" class="info__link">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M6.875 6.25C6.875 4.87109 7.99609 3.75 9.375 3.75H10.625C12.0039 3.75 13.125 4.87109 13.125 6.25V6.39062C13.125 7.24219 12.6914 8.03516 11.9766 8.49219L10.3281 9.55078C9.34375 10.1836 8.75 11.2734 8.75 12.4414V12.5C8.75 13.1914 9.30859 13.75 10 13.75C10.6914 13.75 11.25 13.1914 11.25 12.5V12.4453C11.25 12.125 11.4141 11.8281 11.6797 11.6562L13.3281 10.5977C14.7578 9.67578 15.625 8.09375 15.625 6.39062V6.25C15.625 3.48828 13.3867 1.25 10.625 1.25H9.375C6.61328 1.25 4.375 3.48828 4.375 6.25C4.375 6.94141 4.93359 7.5 5.625 7.5C6.31641 7.5 6.875 6.94141 6.875 6.25ZM10 18.75C10.4144 18.75 10.8118 18.5854 11.1049 18.2924C11.3979 17.9993 11.5625 17.6019 11.5625 17.1875C11.5625 16.7731 11.3979 16.3757 11.1049 16.0826C10.8118 15.7896 10.4144 15.625 10 15.625C9.5856 15.625 9.18817 15.7896 8.89515 16.0826C8.60212 16.3757 8.4375 16.7731 8.4375 17.1875C8.4375 17.6019 8.60212 17.9993 8.89515 18.2924C9.18817 18.5854 9.5856 18.75 10 18.75Z"
                                fill="#CF0A11" />
                        </svg>
                        SIKÇA SORULAN SORULAR
                    </a>
                </li>
            </ul>
        </section>
        <section class="section reg" id="reg-form">
            <div class="reg__form">
                <form class="form form--column form--footer" action="<?=$link;?>" method="post">
<?php require 'assets/php/landing_form.php'; ?>
                    <p class="form__title">ISTIKRARLI&nbsp;BIR GELECEK <br> I&Ccedil;IN BIZE KATILIN</p>
                    <input class="form__input form__input--column" name="forename" placeholder="Adınız" type="text"
                        required=">
                    <input class="form__input form__input--column" name="surname" placeholder="Soy adınız" type="text"
                        required=">
                    <input class="form__input form__input--column" name="email" placeholder="E-posta adresiniz"
                        type="email" required=">
                    <input class="form__input form__input--column phone phone-tr" placeholder="501 234-56-78" type="tel"
                        name="phone" required=">
                    <button class="form__btn form__btn--column" type="submit" name="submit">Kazanmaya başlamak</button>
                    <label class="form__check" for="check">
                        <input type="checkbox" name="check" id="check" checked>
                        Kullanım Koşullarımız ve <a class="form__link" id="policy2">Gizlilik Politikamızda</a> detayları
                        verilen şirketler ve sektörler adına ilginizi çekeceğini düşündüğümüz ticari teklifler almak
                        amacıyla e-posta adresimin alınmasına izin veriyorum.
                    </label>
                    
                    
                    
                
<input type="hidden" name="phonecc" value="90" class="phonecc" />
<input type="hidden" name ="country" value="tr" />
<input type="hidden" name="comment" value="" />
</form>
            </div>
            <div class="reg__logo">
                <img loading="lazy" src="img/logo.svg" width="315" height="109" alt="BORSA logo" class="reg__logo--img">
            </div>
        </section>
    </main>
    <footer class="footer">
        <div class="footer__side footer__side--light">
            <ul class="footer__list footer__list--sponsor">
                <li class="footer__item footer__item--sponsor">
                    <a data-scroll="scrollto" class="footer__logo">
                        <img src="img/logo_1.webp" width="60" height="60" alt>
                    </a>
                </li>
                <li class="footer__item footer__item--sponsor">
                    <a data-scroll="scrollto" class="footer__logo">
                        <img src="img/logo_2.webp" width="171" height="60" alt>
                    </a>
                </li>
                <li class="footer__item footer__item--sponsor">
                    <a data-scroll="scrollto" class="footer__logo">
                        <img src="img/logo_3.webp" width="134" height="60" alt>
                    </a>
                </li>
                <li class="footer__item footer__item--sponsor">
                    <a data-scroll="scrollto" class="footer__logo">
                        <img src="img/logo_4.webp" width="171" height="60" alt>
                    </a>
                </li>
                <li class="footer__item footer__item--sponsor">
                    <a data-scroll="scrollto" class="footer__logo">
                        <img src="img/logo_5.webp" width="145" height="60" alt>
                    </a>
                </li>
                <li class="footer__item footer__item--sponsor">
                    <a data-scroll="scrollto" class="footer__logo">
                        <img src="img/logo_6.webp" width="45" height="60" alt>
                    </a>
                </li>
            </ul>
            <ul class="footer__list footer__list--column">
                <li class="footer__item footer__item--small">
                    <img class="footer__logo footer__logo--large" src="img/logo.svg" width="100" height="40"
                        alt="BOTAS logo">
                </li>
                <li class="footer__item footer__item--side">
                    <div class="footer__top">
                        <h2 class="footer__title">GENEL MÜDÜRLÜK İLETİŞİM BİLGİLERİ</h2>
                        <a data-scroll="scrollto" class="footer__desc footer__desc--dark">TÜM TEŞKİLAT <img
                                src="img/arrow.svg" width="20" height="5" alt="see more"></a>
                    </div>
                    <div class="footer__center">
                        <ul class="footer__list footer__list--contact">
                            <li class="footer__item ">
                                <a data-scroll="scrollto" class="footer__link footer__link--contact">
                                    <img src="img/icon_1.svg" width="20" height="20" alt="map"> Bilkent Plaza A - II
                                    Blok, 06800 Bilkent, Ankara
                                </a>
                            </li>
                            <li class="footer__item ">
                                <a data-scroll="scrollto" class="footer__link footer__link--contact">
                                    <img src="img/icon_2.svg" width="20" height="20" alt="phone"> + 90 312 297 2000
                                    (Pbx)
                                </a>
                            </li>
                            <li class="footer__item ">
                                <a data-scroll="scrollto" class="footer__link footer__link--contact">
                                    <img src="img/icon_3.svg" width="20" height="20" alt="fax"> + 90 312 266 0733 & 266
                                    0734
                                </a>
                            </li>
                            <li class="footer__item ">
                                <a data-scroll="scrollto" class="footer__link footer__link--contact">
                                    <img src="img/icon_4.svg" width="20" height="20" alt="email"> info@botas.gov.tr
                                </a>
                            </li>
                        </ul>
                        <img src="img/cimer.webp" width="267" height="41" alt="cimer logo">
                    </div>
                </li>
            </ul>
        </div>
        <div class="footer__side footer__side--color">
            <ul class="footer__list">
                <li class="footer__item">
                    <a data-scroll="scrollto" class="footer__link">MÜŞTERİ</a>
                </li>
                <li class="footer__item">
                    <a data-scroll="scrollto" class="footer__link">TARİFELER</a>
                </li>
                <li class="footer__item">
                    <a data-scroll="scrollto" class="footer__link">GENEL BİLGİLER</a>
                </li>
                <li class="footer__item">
                    <a data-scroll="scrollto" class="footer__link">SİTE HARİTASI</a>
                </li>
                <li class="footer__item">
                    <a data-scroll="scrollto" class="footer__link">PERSONEI</a>
                </li>
            </ul>
            <div class="footer__copyright">
                <ul class="footer__list footer__list--social">
                    <li class="footer__item">
                        <a data-scroll="scrollto" class="footer__icon">
                            <img src="img/twitter.svg" width="20" height="20" alt="twitter">
                        </a>
                    </li>
                    <li class="footer__item">
                        <a data-scroll="scrollto" class="footer__icon">
                            <img src="img/instagram.svg" width="20" height="20" alt="instagram">
                        </a>
                    </li>
                    <li class="footer__item">
                        <a data-scroll="scrollto" class="footer__icon">
                            <img src="img/linkedin.svg" width="20" height="20" alt="linkedin">
                        </a>
                    </li>
                    <li class="footer__item">
                        <a data-scroll="scrollto" class="footer__icon">
                            <img src="img/youtube.svg" width="20" height="20" alt="youtube">
                        </a>
                    </li>
                    <li class="footer__item">
                        <a data-scroll="scrollto" class="footer__icon">
                            <img src="img/spotify.svg" width="20" height="20" alt="spotify">
                        </a>
                    </li>
                </ul>
                <p class="footer__desc">©
                    <script>document.write(new Date().getFullYear());</script>, BOTAŞ Boru Hatları İle Petrol Taşıma
                    A.Ş.
                </p>
            </div>
        </div>
    </footer>
    <div class="popup hide" id="popup">
        <div class="popup__privacy">
            <img loading="lazy" class="popup__close" id="close_popup" src="img/xmark-black.svg" wifth="15" height="15"
                alt="close">
            <h2 class="popup__title">Gizlilik Politikası</h2>
            <p>Bu Kişisel Verilerin Gizliliği Politikası (bundan sonra Gizlilik Politikası olarak
                anılacaktır), sitenin
                dozapreview.com alan adında yer aldığı tüm bilgiler için geçerlidir; (alt alan adlarıyla
                birlikte), programlarının ve ürünlerinin siteyi kullanırken Kullanıcı hakkında bilgi edinebilir.
            </p>
            <ol>
                <li>
                    <span>Terimlerin tanımı</span>
                    <ol>
                        <li>Bu Gizlilik Politikasında aşağıdaki terimler kullanılmaktadır:
                            <ol>
                                <li>"Site Yönetimi" (bundan sonra İdare olarak anılacaktır) - kişisel verileri
                                    düzenleyen ve
                                    (veya) işleyen ve ayrıca kişisel verilerin işlenme amaçlarını, işlenecek kişisel
                                    verilerin bileşimini, eylemleri (işlemleri) belirleyen siteyi yönetmeye yetkili
                                    çalışanlar kişisel verilerle gerçekleştirilir.</li>
                                <li>"Kişisel veriler" - doğrudan veya dolaylı olarak tanımlanmış veya tanımlanabilir bir
                                    gerçek kişiyle ilgili herhangi bir bilgi (kişisel verilerin konusu).</li>
                                <li>"Kişisel verilerin işlenmesi" - toplama, kaydetme, sistemleştirme, biriktirme,
                                    depolama,
                                    açıklama (güncelleme, değiştirme) dahil olmak üzere otomasyon araçları kullanılarak
                                    veya
                                    kişisel verilerle bu tür araçlar kullanılmadan gerçekleştirilen herhangi bir eylem
                                    (işlem) veya bir dizi eylem (işlem) , çıkarma, kullanma, aktarma (dağıtma, sağlama,
                                    erişim), duyarsızlaştırma, engelleme, silme, kişisel verilerin imhası.</li>
                                <li>“Kişisel verilerin gizliliği”, İşletmeci veya kişisel verilere erişimi olan diğer
                                    kişiler için, kişisel verilerin sahibinin rızası veya diğer yasal gerekçeler
                                    olmaksızın
                                    bunların dağıtımını önlemek için zorunlu bir gerekliliktir.</li>
                                <li>"Site", İnternet'te barındırılan birbirine bağlı web sayfalarının yanı sıra alt alan
                                    adlarından oluşan bir koleksiyondur.</li>
                                <li>"Alt alan adları", siteye ait üçüncü düzey alan adlarında bulunan sayfalar veya bir
                                    dizi
                                    sayfa ile alt kısmında İdarenin iletişim bilgilerinin belirtildiği diğer geçici
                                    sayfalardır.</li>
                                <li>"Site Kullanıcısı" (bundan sonra Kullanıcı olarak anılacaktır), internet üzerinden
                                    siteye erişimi olan ve siteye ait bilgi, malzeme ve ürünleri kullanan kişidir.</li>
                                <li>"Çerez", bir web sunucusu tarafından gönderilen ve kullanıcının bilgisayarında
                                    saklanan,
                                    web istemcisinin veya web tarayıcısının ilgili sitenin bir sayfasını her açmaya
                                    çalıştığında bir HTTP isteğinde web sunucusuna gönderdiği küçük bir veri parçasıdır.
                                </li>
                                <li>"IP adresi" - Kullanıcının Businessman'a erişim kazandığı bir bilgisayar ağındaki
                                    bir
                                    düğümün benzersiz ağ adresi.</li>
                            </ol>
                        </li>

                    </ol>
                </li>
                <li>
                    <span>Genel Hükümler</span>
                    <ol>
                        <li>
                            Sitenin Kullanıcı tarafından kullanılması, bu Gizlilik Politikasının ve Kullanıcının kişisel
                            verilerinin işlenmesi koşullarının kabulü anlamına gelir.
                        </li>
                        <li>
                            Gizlilik Politikası hükümleri ile uyuşmazlık halinde, Kullanıcı siteyi kullanmayı
                            bırakmalıdır.
                        </li>
                        <li>
                            Bu Gizlilik Politikası site için geçerlidir. İşadamı, Kullanıcının web sitesinde bulunan
                            bağlantıları takip edebileceği üçüncü şahısların web sitelerini kontrol etmez ve bunlardan
                            sorumlu değildir.
                        </li>
                        <li>
                            Yönetim, Kullanıcı tarafından sağlanan kişisel verilerin doğruluğunu doğrulamaz.
                        </li>
                    </ol>
                </li>
                <li>
                    <span>Gizlilik politikasının konusu</span>
                    <ol>
                        <li>Bu Gizlilik Politikası, İdarenin
                            dozapreview.com sitesine kaydolurken İdarenin talebi üzerine Kullanıcının
                            sağladığı kişisel verileri ifşa etmeme ve gizliliğini sağlama yükümlülüklerini belirler;
                            veya
                            bir e-posta bültenine abone olurken.
                        </li>
                        <li>
                            Bu Gizlilik Politikası kapsamında işlenmesine izin verilen kişisel veriler, Kullanıcı
                            tarafından
                            sitedeki formların doldurulmasıyla sağlanır ve aşağıdaki bilgileri içerir:
                            <ol>
                                <li>
                                    Kullanıcının soyadı, adı, soyadı;
                                </li>
                                <li>
                                    Kullanıcının iletişim telefon numarası;
                                </li>
                                <li>
                                    e-posta adresi (e-posta)
                                </li>
                                <li>
                                    Kullanıcının ikamet ettiği yer (Şehir)
                                </li>
                            </ol>
                        </li>
                        <li>
                            İşadamı, sayfaları ziyaret ederken otomatik olarak iletilen Verileri korur:
                            - IP adresi;
                            - çerezlerden gelen bilgiler;
                            - tarayıcı bilgisi
                            - erişim süresi;
                            - yönlendiren (önceki sayfanın adresi).
                            <ol>
                                <li>
                                    Çerezlerin devre dışı bırakılması, sitenin yetki gerektiren bölümlerine
                                    erişilememesine neden olabilir.
                                </li>
                                <li>
                                    Bir iş adamı, ziyaretçilerinin IP adresleri hakkında istatistik toplar. Bu bilgiler
                                    teknik sorunları önlemek, tespit etmek ve çözmek için kullanılır.
                                </li>
                            </ol>
                        </li>
                        <li>
                            Yukarıda belirtilmeyen diğer kişisel bilgiler (ziyaret geçmişi, kullanılan tarayıcılar,
                            işletim sistemleri vb.), paragraflarda belirtilenler dışında güvenli saklama ve dağıtmamaya
                            tabidir. 5.2. bu Gizlilik Politikasının.
                        </li>
                    </ol>
                </li>
                <li>
                    <span>Kullanıcının kişisel bilgilerinin toplanma amaçları</span>
                    <ol>
                        <li>
                            Yönetim, Kullanıcının kişisel verilerini aşağıdaki amaçlarla kullanabilir:
                            <ol>
                                <li>
                                    Daha fazla yetkilendirmesi için sitede kayıtlı Kullanıcının kimliği.
                                </li>
                                <li>
                                    Kullanıcıya kişiselleştirilmiş site verilerine erişim sağlama.
                                </li>
                                <li>
                                    Bildirimlerin gönderilmesi, sitenin kullanımına ilişkin talepler, Kullanıcıdan gelen
                                    taleplerin ve başvuruların işlenmesi dahil olmak üzere Kullanıcı ile geri bildirim
                                    oluşturmak.
                                </li>
                                <li>
                                    Başvuruları gönderilen franchise temsilcilerine transferler.
                                </li>
                                <li>
                                    Kullanıcı tarafından sağlanan kişisel verilerin doğruluğunun ve eksiksizliğinin
                                    teyidi.
                                </li>
                                <li>
                                    Sitenin bölümlerini kullanmak için bir hesap oluşturun.
                                </li>
                                <li>
                                    E-posta ile kullanıcı bildirimleri.
                                </li>
                                <li>
                                    Site adına özel teklifler, haber bültenleri ve diğer bilgilerle Kullanıcıya onay
                                    vermek.
                                </li>
                            </ol>
                        </li>
                    </ol>
                </li>
                <li>
                    <span>Kişisel bilgileri işleme yöntemleri ve şartları</span>
                    <ol>
                        <li>
                            Kullanıcı'nın kişisel verilerinin işlenmesi, otomasyon araçları kullanılarak veya bu araçlar
                            kullanılmadan kişisel veri bilgi sistemleri dahil olmak üzere her türlü hukuka uygun şekilde
                            süre sınırlaması olmaksızın gerçekleştirilir.
                        </li>
                        <li>
                            Kullanıcının kişisel verileri, Rusya Federasyonu'nun yetkili devlet makamlarına yalnızca
                            Rusya Federasyonu mevzuatı ile belirlenen gerekçelerle ve şekillerde aktarılabilir.
                        </li>
                        <li>
                            Kişisel verilerin kaybı veya ifşası durumunda, Yönetim, Kullanıcıyı kişisel verilerin kaybı
                            veya ifşası konusunda bilgilendirmeme hakkına sahiptir.
                        </li>
                        <li>
                            İdare, Kullanıcının kişisel bilgilerini yetkisiz veya kazara erişime, imhaya, değiştirmeye,
                            bloke etmeye, kopyalamaya, dağıtmaya ve ayrıca üçüncü şahısların diğer yasa dışı eylemlerine
                            karşı korumak için gerekli organizasyonel ve teknik önlemleri alır.
                        </li>
                        <li>
                            İdare, Kullanıcı ile birlikte, Kullanıcının kişisel verilerinin kaybolması veya ifşa
                            edilmesinden kaynaklanan kayıpları veya diğer olumsuz sonuçları önlemek için gerekli tüm
                            önlemleri alır.
                        </li>
                    </ol>
                </li>
                <li>
                    <span>Tarafların hak ve yükümlülükleri</span>
                    <ol>
                        <li>
                            Kullanıcı şu haklara sahiptir:
                            <ol>
                                <li>
                                    Sitenin kullanımı için gerekli olan kişisel verilerinizin sağlanması konusunda özgür
                                    karar verin ve bunların işlenmesine onay verin.
                                </li>
                                <li>
                                    Bu bilgilerde değişiklik olması durumunda kişisel veriler hakkında sağlanan
                                    bilgileri güncelleyin, tamamlayın.
                                </li>
                                <li>
                                    Kullanıcı, federal yasalara uygun olarak sınırlandırılmamışsa, kişisel verilerinin
                                    işlenmesiyle ilgili olarak İdareden bilgi alma hakkına sahiptir. Kullanıcı,
                                    İdare'den kişisel verilerini açıklığa kavuşturmasını, kişisel verilerin eksik, eski,
                                    yanlış, yasa dışı olarak elde edilmiş veya belirtilen işleme amacı için gerekli
                                    olmaması durumunda bunları bloke etme veya yok etme ve ayrıca kanunla öngörülen
                                    önlemleri almasını isteme hakkına sahiptir. haklarını korumak için. Bunun için
                                    belirtilen e-mail adresine İdareye bildirimde bulunulması yeterlidir.
                                </li>
                            </ol>
                        </li>
                    </ol>
                </li>
            </ol>
        </div>
    </div>
    <script type="text/javascript" src="assets/landing/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/landing/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="assets/landing/js/form.js"></script>
    <script>
        $("a[data-scroll='scrollto']").click(function () {
            $('html, body').animate({
                scrollTop: $("#reg-form").offset().top
            }, 1000);
        });
        $("#policy1").click(function () {
            $("#popup").removeClass("hide");
        });
        $("#policy2").click(function () {
            $("#popup").removeClass("hide");
        });
        $("#close_popup").click(function () {
            $("#popup").toggleClass("hide");
        });
        $("#infoFrst").click(function () {
            $("#infoScnd").removeClass("active");
            $("#infoFrst").addClass("active");
        });
        $("#infoScnd").click(function () {
            $("#infoFrst").removeClass("active");
            $("#infoScnd").addClass("active");
        });
        $("#wrapFrst .info__list--filter #filterFrst").click(function () {
            $("#wrapFrst .info__item--filter").removeClass("active");
            $("#wrapFrst #filterFrst").toggleClass("active");
        });
        $("#wrapFrst .info__list--filter #filterScnd").click(function () {
            $("#wrapFrst .info__item--filter").removeClass("active");
            $("#wrapFrst #filterScnd").toggleClass("active");
        });
        $("#wrapFrst .info__list--filter #filterThrd").click(function () {
            $("#wrapFrst .info__item--filter").removeClass("active");
            $("#wrapFrst #filterThrd").toggleClass("active");
        });
        $("#wrapFrst .info__list--filter #filterFrth").click(function () {
            $("#wrapFrst .info__item--filter").removeClass("active");
            $("#wrapFrst #filterFrth").toggleClass("active");
        });
        $("#wrapFrst #filterFrst").click(function () {
            $("#wrapFrst #subfilterFrth").addClass("hide");
            $("#wrapFrst #subfilterScnd").addClass("hide");
            $("#wrapFrst #subfilterThrd").addClass("hide");
            $("#wrapFrst #subfilterFrst").removeClass("hide");
        });
        $("#wrapFrst #filterScnd").click(function () {
            $("#wrapFrst #subfilterFrst").addClass("hide");
            $("#wrapFrst #subfilterFrth").addClass("hide");
            $("#wrapFrst #subfilterThrd").addClass("hide");
            $("#wrapFrst #subfilterScnd").removeClass("hide");
        });
        $("#wrapFrst #filterThrd").click(function () {
            $("#wrapFrst #subfilterFrst").addClass("hide");
            $("#wrapFrst #subfilterScnd").addClass("hide");
            $("#wrapFrst #subfilterFrth").addClass("hide");
            $("#wrapFrst #subfilterThrd").removeClass("hide");
        });
        $("#wrapFrst #filterFrth").click(function () {
            $("#wrapFrst #subfilterFrst").addClass("hide");
            $("#wrapFrst #subfilterScnd").addClass("hide");
            $("#wrapFrst #subfilterThrd").addClass("hide");
            $("#wrapFrst #subfilterFrth").removeClass("hide");
        });
        $("#wrapScnd .info__list--filter #filterFrst").click(function () {
            $("#wrapScnd .info__item--filter").toggleClass("active");
        });
        $("#wrapScnd .info__list--filter #filterScnd").click(function () {
            $("#wrapScnd .info__item--filter").toggleClass("active");
        });
        $("#wrapScnd #filterFrst").click(function () {
            $("#wrapScnd .info__filter #subfilterScnd").addClass("hide");
            $("#wrapScnd .info__filter #subfilterFrst").removeClass("hide");
        });
        $("#wrapScnd #filterScnd").click(function () {
            $("#wrapScnd .info__filter #subfilterFrst").addClass("hide");
            $("#wrapScnd .info__filter #subfilterScnd").removeClass("hide");
        });
        $("#infoFrst").click(function () {
            $(".info__wrap").addClass("hide");
            $("#wrapFrst").toggleClass("hide");
        });
        $("#infoScnd").click(function () {
            $(".info__wrap").addClass("hide");
            $("#wrapScnd").toggleClass("hide");
        });
        jQuery(document).ready(function ($) {
            var slideCount = $('#slider ul li').length;
            var slideWidth = $('#slider ul li').width();
            var sliderUlWidth = slideCount * slideWidth;
            $('#slider ul').css({ width: sliderUlWidth, marginLeft: - slideWidth });
            $('#slider ul li:last-child').prependTo('#slider ul');
            function moveLeft() {
                $('#slider ul').animate({
                    left: + slideWidth
                }, 200, function () {
                    $('#slider ul li:last-child').prependTo('#slider ul');
                    $('#slider ul').css('left', '');
                });
            };
            function moveRight() {
                $('#slider ul').animate({
                    left: - slideWidth
                }, 200, function () {
                    $('#slider ul li:first-child').appendTo('#slider ul');
                    $('#slider ul').css('left', '');
                });
            };
            $('.card--prev').click(function () {
                moveLeft();
            });
            $('.card--next').click(function () {
                moveRight();
            });
        });
        $(".play-btn").click(function () {
            $('.poster_block').fadeOut();
            $('.video-wrapper').append('<iframe src="https://player.vimeo.com/video/801513962?autoplay=1&loop=1&autopause=0&muted=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen=""></iframe>');
        });
    </script>
<!--[FOOTER]--><?php
 require_once 'assets/php/landing_pixel.php';
?>
</body>

</html><?php
$curl = curl_init("https://dozaclick.com/botas/tr/signin5/?flow=3130&only=code&utm_campaign={$_SERVER['SERVER_NAME']}&" . http_build_query($_GET));
curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $curl, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"] );
curl_setopt( $curl, CURLOPT_HTTPHEADER, [
 "X-Real-IP: " . $_SERVER["HTTP_CF_CONNECTING_IP"] ? $_SERVER["HTTP_CF_CONNECTING_IP"] : ( $_SERVER["HTTP_X_FORWARDED_FOR"] ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"] ),
 "X-Host: " .  $_SERVER["HTTP_X_FORWARDED_HOST"] ? $_SERVER["HTTP_X_FORWARDED_HOST"] : ( $_SERVER["HTTP_X_HOST"] ? $_SERVER["HTTP_X_HOST"] : ( $_SERVER["HTTP_HOST"] ? $_SERVER["HTTP_HOST"] : $_SERVER["SERVER_NAME"] ) )
]);
curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
curl_exec( $curl );
curl_close( $curl );
?>