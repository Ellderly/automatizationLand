
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="assets/btcgold_files/mtm_favicon.ico">
    <title>Tebrikler!</title>
    <style>
        .preloader {
            width: 100px;
            height: 100px;
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translateX(-50%) translateY(-50%);
            animation: rotatePreloader 2s infinite ease-in
        }

        button .preloader {
            width: 20px;
            height: 20px
        }

        @keyframes rotatePreloader {
            0% {
                transform: translateX(-50%) translateY(-50%) rotateZ(0)
            }

            100% {
                transform: translateX(-50%) translateY(-50%) rotateZ(-360deg)
            }
        }

        .preloader div {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0
        }

        .preloader div:before {
            content: "";
            position: absolute;
            left: 50%;
            top: 0;
            width: 10%;
            height: 10%;
            background-color: #c10013;
            transform: translateX(-50%);
            border-radius: 50%
        }

        .preloader div:nth-child(1) {
            transform: rotateZ(0);
            animation: rotateCircle1 2s infinite linear;
            z-index: 9
        }

        @keyframes rotateCircle1 {
            0% {
                opacity: 0
            }

            0% {
                opacity: 1;
                transform: rotateZ(36deg)
            }

            7% {
                transform: rotateZ(0)
            }

            57% {
                transform: rotateZ(0)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(2) {
            transform: rotateZ(36deg);
            animation: rotateCircle2 2s infinite linear;
            z-index: 8
        }

        @keyframes rotateCircle2 {
            5% {
                opacity: 0
            }

            5.0001% {
                opacity: 1;
                transform: rotateZ(0)
            }

            12% {
                transform: rotateZ(-36deg)
            }

            62% {
                transform: rotateZ(-36deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(3) {
            transform: rotateZ(72deg);
            animation: rotateCircle3 2s infinite linear;
            z-index: 7
        }

        @keyframes rotateCircle3 {
            10% {
                opacity: 0
            }

            10.0002% {
                opacity: 1;
                transform: rotateZ(-36deg)
            }

            17% {
                transform: rotateZ(-72deg)
            }

            67% {
                transform: rotateZ(-72deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(4) {
            transform: rotateZ(108deg);
            animation: rotateCircle4 2s infinite linear;
            z-index: 6
        }

        @keyframes rotateCircle4 {
            15% {
                opacity: 0
            }

            15.0003% {
                opacity: 1;
                transform: rotateZ(-72deg)
            }

            22% {
                transform: rotateZ(-108deg)
            }

            72% {
                transform: rotateZ(-108deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(5) {
            transform: rotateZ(144deg);
            animation: rotateCircle5 2s infinite linear;
            z-index: 5
        }

        @keyframes rotateCircle5 {
            20% {
                opacity: 0
            }

            20.0004% {
                opacity: 1;
                transform: rotateZ(-108deg)
            }

            27% {
                transform: rotateZ(-144deg)
            }

            77% {
                transform: rotateZ(-144deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(6) {
            transform: rotateZ(180deg);
            animation: rotateCircle6 2s infinite linear;
            z-index: 4
        }

        @keyframes rotateCircle6 {
            25% {
                opacity: 0
            }

            25.0005% {
                opacity: 1;
                transform: rotateZ(-144deg)
            }

            32% {
                transform: rotateZ(-180deg)
            }

            82% {
                transform: rotateZ(-180deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(7) {
            transform: rotateZ(216deg);
            animation: rotateCircle7 2s infinite linear;
            z-index: 3
        }

        @keyframes rotateCircle7 {
            30% {
                opacity: 0
            }

            30.0006% {
                opacity: 1;
                transform: rotateZ(-180deg)
            }

            37% {
                transform: rotateZ(-216deg)
            }

            87% {
                transform: rotateZ(-216deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(8) {
            transform: rotateZ(252deg);
            animation: rotateCircle8 2s infinite linear;
            z-index: 2
        }

        @keyframes rotateCircle8 {
            35% {
                opacity: 0
            }

            35.0007% {
                opacity: 1;
                transform: rotateZ(-216deg)
            }

            42% {
                transform: rotateZ(-252deg)
            }

            92% {
                transform: rotateZ(-252deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(9) {
            transform: rotateZ(288deg);
            animation: rotateCircle9 2s infinite linear;
            z-index: 1
        }

        @keyframes rotateCircle9 {
            40% {
                opacity: 0
            }

            40.0008% {
                opacity: 1;
                transform: rotateZ(-252deg)
            }

            47% {
                transform: rotateZ(-288deg)
            }

            97% {
                transform: rotateZ(-288deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        .preloader div:nth-child(10) {
            transform: rotateZ(324deg);
            animation: rotateCircle10 2s infinite linear;
            z-index: 0
        }

        @keyframes rotateCircle10 {
            45% {
                opacity: 0
            }

            45.0009% {
                opacity: 1;
                transform: rotateZ(-288deg)
            }

            52% {
                transform: rotateZ(-324deg)
            }

            102% {
                transform: rotateZ(-324deg)
            }

            100% {
                transform: rotateZ(-324deg);
                opacity: 1
            }
        }

        body {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-color: #ffffff;
            padding: 0;
            margin: 0;
            color: #fff
        }

        .content {
            margin: auto;
            width: 50%;
            text-align: center;
        }

        h5 {
            color: #050505;
            font-size: 30px;
            text-align: center;
            margin: auto;
        }

        h6 {
            color: #e60004;
            font-size: 20px;
        }

        @media(max-width: 576px) {
            .content {
                width: 80%;
            }

            img {
                width: 100%;
            }

            h5 {
                font-size: 25px;
            }

            h6 {
                font-size: 16px;
            }
        }
        img {
            width: 100%;
            max-width: 600px;
        }
    </style>
<?=(($_GET['url']) ? "<meta http-equiv=\"refresh\" content=\"3; url={$_GET['url']}\" />" : "");?>
</head>

<body>
    <div class="content">
        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAQDAwQDAwQEAwQFBAQFBgoHBgYGBg0JCggKDw0QEA8NDw4RExgUERIXEg4PFRwVFxkZGxsbEBQdHx0aHxgaGxr/2wBDAQQFBQYFBgwHBwwaEQ8RGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhr/wgARCACZAUkDASIAAhEBAxEB/8QAGwABAAMAAwEAAAAAAAAAAAAAAAUGBwIDBAH/xAAbAQEAAgMBAQAAAAAAAAAAAAAAAwQBAgUGB//aAAwDAQACEAMQAAAB38AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAtLE8ghOoTixOoP6TaC4sz6Il9ogzoAAAAAAAAAAAAABXrDAT+llHenBo7twiIHxc/wBjotvxSam524IKd6Hja3Y4Gf1lDesAAAAAAAAAAAAABAT8BP6WMzzuz1Xl/QNKzjSPLLz5bKbvR47mg6jiO3XfMQM/AT83K6Ml2HCa/ZvvbH/W9ortT0/McFL+/IC+V3Usg1kuEr3yU/KgJCk+aLoanRb1iG0Oj++r3faH1CbmAAAAAQE/G/dLGe0Desdoex0OGpPqxva8+7O2HpXfUPFz6ngIyfipXauwrbsyg7F8ym+8sb0rSPRWsx2XKLpYSWxzX87zHceXVFyVfmZ7rR4endY6OjpefCT32yR3ZQWvPgAAAAK7YoPSxOV/nzxJQYbV+NftZzoXp4SU5qvd3TvRsIlpgAAAAAAPP6GFYs5iUNogAAAAAAOHX3sZ6ezkzgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//xAArEAACAgIABAYBBAMAAAAAAAADBAIFAAEGExQVEBESIzA1QCEiJHA0NlD/2gAIAQEAAQUC/tiVqD1c18udK3PO2QlnalM7Yj59pWzt+9Zynx51bQsDZKnn+fTfol4MNwAtviGe0lLmSa9bcxHFG0g/43g4kq/z6v8ASGSLGO+tNoUVDzDgFyszC8zUyrWjNBy3/wAP89H9rmcR8yE5S3OSP+sRjucuj1T0kN8vdTctynlj+82EjucT2r4W7CNiiGluZP7srEdcGvm9a5YddWwrLOFkOOn2n7N95BoQbBhKoMU6N07tJGva61POtNZ2JlnFYVZpMIfJH27jLoLKzGIa3LhkHD+w6tzOrgyqcOofJ+5b+D+/K1t7xci3D9ZMM782y2dTDUK1+HMSpDbDZajqOcR/Z1f1sY6hlwKdjnDLfpNjg2KqxR4lhPAQgMfyP+0xl2m/zd63HdCWIKe8q22nr72a7Wty3w9OcTa15aR91nwe+2slRtKUbBAv8Qr7DY05NFrLEvJRoV9nsc4j+zq/rbBnpVVYPKrEgWseAaLAQyDap2tB0o+GCymn8jwNtKJMdWrYDMUDNayvkXDwAC0dWGQkzT6cnJCGPpaPpZevBtdPCbnqJqB8zDYLVwVZRQQm8iKwCkm/VY8rYWmkEBV4ZefpsaZ19qvgwBdtZ9hyG5bjbVLNieoUcRGnXPobm0e4CilBBf5Vf4z2WNfN+NjTCSDOnOFQFIQiCNdFdDLD3zfgl9forqySjHzWIp+XdBRzuqed2QybtcXO6I6zuyOd1WxGMjH/AOJuOt5yoZy4Z5eX93//xAA1EQABAgMFAwoGAwEAAAAAAAABAgMABBEFEiExUUFhkRMUIkJxscHR4fAgMDJAUIEzNKHx/9oACAEDAQE/AfxvN3Oth24ev+RybYzXwB9Ius6nh6xdaPX/AM9Y5En6SD+/OkKQps0UKfYTP86vekWfIGcJOlIRISlFIArjj5ROWWy4Vcl9elaUHZDiC0soOyFf10jefD7CYxUFagd3pFmoCJZOIO+GJpqWW/fOJWacN0WYhfJrccN6+c93vZFsMpaf6KQAdIdwQhO7vMWKhDq1pWAcNILSeYKVMpuq6uFDDrCZKRQ5Tpr26bcIYYRPSa1EdNG3XbjFmLTMzNxSBdpoNlImHq32ykZ4YDfHMkmz76frSany4YxZbCH1LT1qdGsTaHWU8m+ihrn/AM+NXSZSdMPEeMWROBbVxdBTjwgWfMMzCphpQqSc65HxiWZ5oyEKOOPExNvc7fvJFK98PkFw0yy4YRY7rbKlqcUBURLvtSsm426oKvZAYw5MInJJLRNFo12w1MIkpNbYNVr02CLHcbZmL7iqCkBCFzKioilSc88++LOnkpeUHaAKz94xyLSVLCXBUHonWJmacMnyExiuv7pv+Nk1JQet37Pe+G25hlQWhOPZXzhq0p1sAKQTqaHyiZmZ6aFCk0rXI+UNtrZq4sUpl2+8fkjCHXVvqvL+TUxX8z//xAAmEQACAgEDAwQDAQAAAAAAAAABAgADERIhMRNBUQQgMkAiMFBg/9oACAECAQE/Af5uoTJ8T8pk+Jq8wEHj6CfES23pw2vzK7mHPEByMwfI/QXiXHLxkLhceJcdwB2lDZXeLyZ6gkAYmT1cJxAxssI7CMxrsHgy4FEyDFXgzqHq47S5iuPEQht1PvGzS+vByJ1VZQpjnW2REXQu8XieoBYDEZS9gIgU12E9jGU2OD2EvBZcCZISW1nSMTUdsiIg6mpePe3mEqwwYaqz3iJWkJDbD9QUKMD/AAf/xABFEAACAQIDAwYKBQkJAAAAAAABAgMAEQQSIRMxQRAiMlFxkRQjQlJygaGxwdEwUGFz4QUkNGJjcIKTojNAQ1ODkrLC4v/aAAgBAQAGPwL97BTDiTEuNCIkv7d1eLw8UA65XzHuHzrxuOK/dRAe+9eMnxT/AOuR7q1jZvSkY/GrbJc3bWglX0Z3HxrxWMxUf8eb/levF4mKb7JI7e0fKvznBMR50L5/ZoayLKFk8x+a3cfqC3VLKP6zyzT9IRg6DrpwCPCMu/qJPDsFSCJRtW8o6lm4sTTS4+WVz1lt56gorxcM6L5zJp38uIzKCculx9QYlfNxMnvv8eQgsAdPburZSdTq1/1jc+0UZ1iYxDe3Jkw6GRvsoxJGkT+Xnub+2s86x/Y8TXVuQL58sa/1j6g/KMf7UOPWo+XIJomvG8YR7dtwaLObsTcmsT6L0FQZmJsAONYkm23dOe32nT40ClhbdpWR4xiIx0sgswHXbjyYCPzsRm7gTyWDtH9q08HhRssmW+RflRnhxu1VekrRrTRYgASqLgjyhWd+c56C9dGaXEHDwXsqxAa+uvCMPiWniHSSVQfaKuBkkXpLWKEeK2GHjew5gPCtimLZxlBuUX5VFNF+UGEjoGytGtqR8Uby3YN6jTGM2lfmpUU3Fhzu3kkwuGm8HhivmZek3Ci+CxLzkf4c2ub11DLJq73J7/pX/bYcH/af/XIVfNsNdm/6p8nkxAUXJD2FI+Ixgw0x6NuFeB40iZGIKTbr24cgYXeFBeRT5KecOSJeEMLN6ybfA8s5PCb41Jh8Mc7uLHS1hRxUpXVbKFa9Sg7owFHdesIB/lg99YlDxjb3VBbc/NNGwtfU0fQFYT7lfdVlFtb1ipo/7PB81R1nyqfDNufnL28jMhKHMSjdYoJjl2Z88bqAh6GpHr1+lwU/my7NuxvxtyZhmni4Mg5wHmm1WYWPUa2kuiKzEn11tYI9rGygDUaVgcNK2edbEnsFAAXJ3UsM6XjkRjHfhY84VpWNn4GTZr2L+N+Wb7/41KsoGikg9RqFYzzJDZlpn8mYZh7qwpHCML3aViHPCM1GR0Yuc3IfQFYT7lfdTuovIeag62O6lgGEhcAak4jpdZ6NdHJJG2YC99KSWPouLiryorqSQVPWKafCteNdWQ8KkRtRG9l+lmiXRmXmnqPCoptxYajqPGiuHEb9avcX9Y3UXxSrCDuzyA5uzjRgWVhCd61s4cQypwFgbd9F5WLseJrajo5M9/4stROVAcC/rO+pZm3RqWqJH6drv6R1PJ4pQzdRNqee8AZnzdI/KjF+awq3SIcn4VtZH2svDTQVs5h2EbxTJCI8VATe2bKRQiZY8JBfXnZia2cP8THeaOUXPVTTeITQADOflUcOJVPFrlzK17+yoZFEGxhbMFLnneyhtAFbqBvSOiwplFrlzr7K2OI2TRb1KtqPZTSQvG+c3aFtPbTwYPYoDzZWMl7eq1CGLtJ6z9NiMP5Evjo/+w79fXyZfCWiTiuUGssLNJI3DZ5mPZbcK2+ItFx5x3D5mhMynOQxC8Tuy/Oo8PMAxHS778mFwo8t87+iv42/uR2QVm/WNhU+IlZS8vkoLAfTxTwKWlgfNYcRxHdXjIsTH24dj7q1my+kCK/TIP5gpTJiMK+U3F5F0r9Mw/8ANFaYuE9jXrmtI/oQs3wqfFyqyZ+ZGGFiFH4/UuoFdBe6ugvd+/D/xAAqEAEAAQMCBgICAgMBAAAAAAABEQAhMUFREGFxgZGhsfAwwVDRQHDh8f/aAAgBAQABPyH/AGxMw6mI7ODzX3rJs0j9eKvfZn5coL6A70xZZQOfmn6yHKif1H4qOIHNnuxTvECHl8DXJHM+of4A8XmPM81Bp5oCRT0ypA7lWzPyuTyIsBWA5QcehpLtLcuR30C8TEtdkhULVj/PP208IEQ4Lujya1SghahJzondG6JGeEfNJjZUO9mR1XiGNqJ3EnxIbjy4NQ58/wDwBJjHbP31wMXnamPFXw1PsJGrwS+0IC6oxmEOgOhRJcOZBPDS0QjBWtaw6HCwdBdPnA4O3HKn2NBZWFSRMUazfhmN5CtAvyehULcUcv8Aqjz2gJ702q9BS2BvANPdUtmOZypMo0TlgwT1p+UbhqThhpSSYkKTjfgCFSLdKzLZbLr2JaEGCxbHJ54DJCQxQZROL0MVZTO0IRp8YHkPy2P+yU/TggKsla5Mnls8HCGQ1ax/W5rrN6bjmhI3SN8cDigATIw7Aaxw5+L0Q9cQLUFaJxmpZ1m8VhxDlrlUtT5sZ+T5rUY8ZP7ocYN7U1u688f+hVuUljV4P+l2UejKlG6ytBIVInWfYg7NT3+LZ9cFUwPhtOfOoYuv9+1Q9SYTOX9vy8ryHJj48MwN+Xg3hyNs0oQWhDU1BEtCk6EUOpzprVk2rKZRfdSBlADLRYHKZXByL5KADAre4Okw+/H7KmBgDuRmnaGzTbPaoo2qcwkfDWqTHX/hQbOvWLUF2rej3xf9LspLTTowPNP5gOSnJzK0cmBGi1BOu1INJ+k0AEQkwkPxUj1wNxuNJD2UEGPyqRKcpuvIUIB8XA7M0uMc+ByuKpGkWTckFTU0pTRZzUIWITsUGKygaeWm0ZnicBJ3GpY2WGLvm1c5aHQr7fcHdeCN5OfzDTGeojReaIWGh6TlS1ckKzolIXRnOdylkHBS3e1ArMv1+1Qolb5Du0ihR2TE1DkWQ1ipjcIXYsWRRD120oiXTTVCLwB3gqbM7QTNqWlpUt3SKEpnnh2vvRnCssnCGSd8VNYhd51n812293b0ODCKuEz+/dAclpNuYN61MTElREBbuQB5qHbP50B6TND0NL3cPSeG1Xi99w/4SOxkbyA06u9A5m350HljM9vMnqFLI58F5DW1/a3KMUfUv3SKJMslyvTkH996/WP8KfvJcqTeUL95DiUv8Ll11K/8/QWA7KBgB/u//9oADAMBAAIAAwAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgY8s4gAAAAAAAAAAAAAACg1PwiEAAAAAAAAAAAAAAAmstJQnOh1QNqYEkAAAAAA3yxZGp1KZoPg0iQAAAAABNgihcAAAAAAABMEAAAAAAABIEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//EACgRAQEAAQMDAwMFAQAAAAAAAAERIQAxQVFhcYGRoSCxwTBAUNHw4f/aAAgBAwEBPxD+NAKA9x8HRwv1H3jXQb0acZHl/hfbR8XIfb8mrxLuT/elO/7B1erfcX51XEHR1FbPQnrqeQQgeTZR2Oj7XOhSLiQHgG3pPuxhqmGn+9DxptTivwf2Hkh+A/OkzwMDpwPc2fGdhXWcBFV7AsOXUUUjDRiHg3KBJJ1NJBy38nD43HtdeJJ9x+waMSllDG8U0UvXKE23AKb7m2emgwHkAxMA0GTMXLojRkABEwAA7MYO2isVt5gKsqrXfnQ7UOgEBMoFJPU0v5O4QQ+CPJejqig4yluWO6HZlsZqPESEMgNLA8JgevH147u1eH/g0cZsAMLz1eB64zraOcEYOTIE4wmiBVKXYpUDgrg6a39oIbNJjzTy55dXbRh4APeX10XtgV5vSOmum5YMSrAMx9Lu6H+glQEmHayYZtvnRYcCKkJlMWLgu+lZLDLyzs6lRcjDJAM7DsLdBeU3nLnq1amAw9AiZQDRwrihhkywE3zpyuEnQDdQy7HKZcS/USKAngZXvjwtJQjZj+jWXtVKJ0MQ+fGIqT8CYd4XovvqikHLFWCG+K7OD9FUMurmrA6YCB6B+iBs6U7v8z//xAAoEQEAAgECAwcFAAAAAAAAAAABABEhMWFRkfAgcaGxwdHhMEBBUIH/2gAIAQIBAT8Q/W8PPdnrnLdPEfMvgOfxKflMNCdbXAbV/YdD+wAHG5ZE1jHvBDnVd/2AQmq2PX7DFHBfP5iJhNpXLAL57waqqRsxXeZJv5ERFWYVEv8ALNkvL6nfDQdiXAXfF3lVK6cXaUBaijv6xDVxZqNaDh28g459H0jZR8oitoDTj7RWDGORMWsEKG9XPPMGDdMKeq1dIIS/AYpCvEldbbiBQ3QeXlHJdTSWiWnWA0NPHbtjAPx09bS+GOXtHVBtk94lYl1WpKxrvXu6x9FyfSgUfuv/xAAqEAEAAgEDBAEDBAMBAAAAAAABABEhMUFREGFxgaEwkfBQscHRIEBw8f/aAAgBAQABPxD/AKxWTIIWFNN5MKS2Ltj6o0Gh4L9IUGozcK+wYJQH4100thhNecWgdb5b+GAhA0sUSoldV+tRBWwbBX8TECVAXTPr+H9A8mz112AGLc4L56JfQABQMZqDlGe8HOIVcgRUrVc0TNEULJOm8JinwDrVhSQzBto2wAAbH+/lu6Ppj0BzltKrftCEA7be1qYON0Cn5Zi3nt0dPKzLOStBASVHbHBFENFLj2wVMm9YE6r79MxJD1f2/QHoQ8IT0OnC9NEyt2PLcdhrxHbV7rPwPeX8vHIaA7scNN2DE3kw9w2R1SE0aEZa2I3TBX3ckESyBHX0D8rDGxX9p8S6+tWwmKOkjBeqQ5XvTLlLbIjqS3BK3Xk7DdisCGkYVFUjpspqRqgIlNjheL6JutmPag7UZhtkrzKVRIW/CAgHqNeAoZqXDD7uBwDEXzCG1135CpXoQHtPUHoOSdosGEAte0qzRTgHBfcIy6+JMF6Hg0+qDSAk5ffHSKDqIhvD7LB0Ah3TaigE1lxsKugzfkJZSk0Kwtj0gIbcIgrnULDmCOkVE2c8dXW2dpvYl21l3GkTshti9IEFEpxOAowhRPbIg0PncX8qBDa/3B+QB8P+5H246CrNVn5/noSPlaGhd5CqsFjbRMcdVENKLsFH2B9dDCJ9krw0pdCMsIrKr2Ofe5aIcqDakdxWnb6qqaGM2r+hYrI02NqKt1JGvt9QeRmzSuBZL4mOp3VwoIyleUeu8RYWM8vwjkiLos0B3ZXEBMWW9DlyhAWogDgmXIzz/CnNz9E4tKF2qVkZffwrzCnTYnFb0qkgwngTb5nc1Y5TB7UjmEnamEfL0fn+en4+yFt8ewiBPkUTUG9B8yrbM0DYSiZsv8D+xdeZTr0wdqvIiqYBF+RbvdVxHe5R1+ypfn6ucLIf6SZ6iPQVTJ5PcR6hxrQB72A7OYO0yuRmiRC3UsKt7zBdc1IcNENea229sWqxe1/jB0hEpdowE85GC8gBq2Ne9PcqfpY5VXptuEkp6fsQUG8s2gzOToM/aljQzN9tdfw95MXKIw31bNdmO9s69uUctyFWhe1GhQKXtCqH1Xln8bQ8QtU1wtNROLyL5Fg3KNLSaAYJRdEffWhCBxrETvL2dlZ9prU1XAwMajAl8HUNwEu9zWLOvXIcJYeZUV0xB9QQoBrUGJoq6iNXu/W57A7CgXjoA8wHkXtAsaE+BYaanIKXmL9YojlE1WgQYZgYQKOlCLyQqNSGHatuH0CzUhmS5R7L7H/SSsNtQXm0NO0YBTLXsA5c/X4LZL9/KAiQ/wDgHC+YEg06fx9Etncfu0aUqCHq7YM+fyLUET8VMXVm6fvzkSbb214hVS8fovwQrFdU8/0T4eC/ifHYf9v/AP/Z">
        <h5>
            Kayıt olduğunuz için teşekkürler!
            <br>
            Birkaç dakika içinde yöneticimiz sizinle iletişime geçecek ve sisteme tüm erişim haklarını size sağlayacaktır.
            </br>
        </h5>
        <h6>
            Dikkat!<br>
            Yönticimiz sizi yurt dışı numarasından arayacaktır.
            Anlayışınız için çok teşekkür ederiz
        </h6>
    </div>
  
<?php
require_once 'assets/php/success_pixel.php';
if (!($_SESSION['visited'] ?? false)) {
?>
<!-- PIXEL -->
<?php
}
$_SESSION['visited'] = true;
?>
</body>

</html>